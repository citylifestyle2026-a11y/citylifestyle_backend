const mongoose = require("mongoose");
const { toReferenceList } = require("../utils/splitReferences");

/**
 * Contact Model
 *
 * References (see the `references` field below):
 *  - A contact can hold multiple references (e.g. Karan -> [a,b,c,d]).
 *  - Values are trimmed and de-duplicated CASE-INSENSITIVELY within the
 *    SAME contact's own list before saving (see the pre-save /
 *    pre-findOneAndUpdate hooks below) — "a" and "A" on the same
 *    contact are treated as one entry; whichever was typed first is
 *    what's kept.
 *  - The SAME reference value is expected to appear across DIFFERENT
 *    contacts on purpose (e.g. Karan -> [a,b,c,d] and Mahesh -> [a,j,k,l]
 *    both legitimately have "a") — that is NOT a duplicate to prevent,
 *    it's how references are meant to be cross-matched later. Any
 *    future cross-contact lookup should also compare case-insensitively,
 *    which is why `normalizeReferenceKey`/`normalizeReferences` are
 *    exposed as statics below instead of being reimplemented ad hoc in
 *    a later service.
 */
const contactSchema = new mongoose.Schema(
  {
    fullName: {
      type: String,
      required: true,
      trim: true,
    },

    whatsappNumber: {
      type: String,
      required: true,
      trim: true,
    },

    companyName: {
      type: String,
      trim: true,
      default: "",
    },

    // Company Designation (e.g. "Owner", "Manager", "Sales Head") — the
    // contact person's role/title within companyName. Optional at the
    // schema level (kept consistent with companyName/companyCategory
    // above, which are also not `required` here); "all fields except
    // Address are compulsory" is enforced at the request layer instead,
    // see validators/contact.validator.js, the same place
    // fullName/whatsappNumber's required-ness is already enforced
    // alongside this schema's own `required: true`.
    designation: {
      type: String,
      trim: true,
      default: "",
    },

    address: {
      type: String,
      trim: true,
      default: "",
    },

    // Area / locality (e.g. "Adajan", "Vesu") — shown next to Address.
    // Optional, same as address.
    area: {
      type: String,
      trim: true,
      default: "",
    },

    // Instagram username WITHOUT the "@" (normalized by
    // utils/normalizeInstagramId.js). Optional.
    instagramId: {
      type: String,
      trim: true,
      default: "",
    },

    // Contact's profile photo. `profileImage` is the public URL,
    // `profileImagePublicId` is the relative path under uploads/ that
    // utils/deleteLocalFile.js needs to remove the file later — same
    // pair of fields User.model.js already uses.
    profileImage: {
      type: String,
      trim: true,
      default: "",
    },

    profileImagePublicId: {
      type: String,
      trim: true,
      default: "",
    },

    // Contact's email address. Optional at the schema level — no
    // conditional/required logic lives here (Step 2 will add
    // request-layer validation in validators/contact.validator.js, same
    // separation of concerns already used for every other field's
    // "required" rules in this schema/validator pair).
    email: {
      type: String,
      trim: true,
      lowercase: true,
      default: "",
    },

    // Single / Couple. Required at the schema level per this step's
    // spec — every contact must record one or the other. Whether
    // spouseName/spouseMobile are required FOR a given contact depends
    // on this value, but that conditional cross-field rule is Step 2's
    // job (the request-layer validator), not this schema's.
    // Comes from the Contact Book (and the old spouse form). Contacts created
    // from the new form only have `entryType`, so this can be empty.
    relationship: {
      type: String,
      enum: ["Single", "Couple", ""],
      default: "",
    },

    // Entry Type (Single = 1 entry, Couple = 2 entry) - the field the form asks
    // for while the Relationship / spouse section is switched off. Shown in its
    // own "Entry Type" column; Contact Book contacts have it empty and show their
    // `relationship` instead. Pass quantity uses `entryType || relationship`.
    entryType: {
      type: String,
      enum: ["Single", "Couple", "Manual", ""],
      default: "",
    },

    // How many PERSONS this entry stands for: Single = 1, Couple = 2,
    // Manual = the number the admin typed. Form Link progress and the default
    // pass guests count this. 0 = not saved (older guests) -> worked out from
    // entryType / relationship (see utils/persons.js).
    persons: {
      type: Number,
      min: 0,
      default: 0,
    },

    // Only meaningful when relationship is "Couple" — left optional
    // here on purpose; Step 2 adds the conditional-required check.
    spouseName: {
      type: String,
      trim: true,
      default: "",
    },

    // Only meaningful when relationship is "Couple" — left optional
    // here on purpose; Step 2 adds the conditional-required check.
    spouseMobile: {
      type: String,
      trim: true,
      default: "",
    },

    // Spouse's Instagram username (Couple only, no "@") and profile
    // photo — same shape as instagramId / profileImage above.
    spouseInstagramId: {
      type: String,
      trim: true,
      default: "",
    },

    spouseProfileImage: {
      type: String,
      trim: true,
      default: "",
    },

    spouseProfileImagePublicId: {
      type: String,
      trim: true,
      default: "",
    },

    // Profession / Occupation — intentionally a NEW, separate field
    // from `designation` above. `designation` is the contact's title
    // WITHIN companyName (e.g. "Sales Head" at a specific company);
    // `profession` is their general profession/occupation and is
    // independent of companyName/designation. Optional at the schema
    // level for now (Step 2 handles any request-layer requirement).
    profession: {
      type: String,
      trim: true,
      default: "",
    },

    // Original casing is preserved for display — matching/de-dup is
    // case-insensitive (see normalizeReferences below) but nothing here
    // lowercases the stored value itself.
    references: {
      type: [
        {
          type: String,
          trim: true,
        },
      ],
      default: [],
    },

    // References models/companyCategory.model.js. Optional — a contact
    // isn't required to have a category assigned.
    companyCategory: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "CompanyCategory",
      default: null,
    },

    // Spouse's profession CATEGORY (Couple only), picked from the same
    // Company Category master list. It is what makes a Couple contact
    // also appear under the spouse's category in the Contact List's
    // Company Category column and in its Company Category filter.
    professionCategory: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "CompanyCategory",
      default: null,
    },

    // Mirrors Admin/User's active/inactive status convention (as
    // opposed to Event's Active/Expired, which is specifically
    // time-based expiry and doesn't apply here).
    status: {
      type: String,
      enum: ["active", "inactive"],
      default: "active",
    },

    // true = created automatically by Entry Report -> Add to Event History
    // (services/eventHistorySync.service.js) purely so the history row has
    // a person to point at. Such contacts are NOT shown in Contact List;
    // adding the same number manually later "promotes" it (see
    // contact.service.js createContact).
    historyOnly: {
      type: Boolean,
      default: false,
    },

    // ================= EDITION (MOVED FROM MEMBER LIST) =================
    // Set when the contact is moved from Member List to Guest List for an
    // edition (event). Guest List can be filtered by it.
    editionEventId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Event",
      default: null,
    },

    editionName: {
      type: String,
      trim: true,
      default: "",
    },

    memberId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Member",
      default: null,
    },

    // ================= APPROVAL (PUBLIC FORM SUBMISSIONS) =================
    // Public form submissions are saved as "pending" and an admin then
    // approves / rejects them from Contact List. Contacts added by an admin
    // (and every contact that existed before this field was added) are
    // "approved" — missing field is also treated as approved by the list
    // filter (see buildContactQuery in services/contact.service.js).
    approvalStatus: {
      type: String,
      enum: ["pending", "approved", "rejected"],
      default: "approved",
    },

    approvalUpdatedAt: {
      type: Date,
      default: null,
    },

    approvalUpdatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Admin",
      default: null,
    },

    // Set when the guest came in through a "Form Links" link. Lets the link
    // export exactly the people who filled THAT link (even if the link is
    // renamed later). Older guests have none - the export falls back to the
    // Reference name for them.
    formLinkId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "FormLink",
      default: null,
    },

    // Last time an invitation pass was sent to this contact over WhatsApp
    // (see sendPassToContacts in services/contact.service.js).
    passSentAt: {
      type: Date,
      default: null,
    },

    passEventId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Event",
      default: null,
    },

    // The booking created by "Send Pass". Lets Resend Pass / pass
    // cancellation (Pending / Rejected after a pass was sent) find the
    // exact booking. Older contacts without it fall back to a lookup by
    // WhatsApp number + event (see findActivePassBookings).
    passBookingId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Booking",
      default: null,
    },

    // Last time the polite "next Parv" WhatsApp message was sent because
    // this contact was marked Rejected.
    rejectionMessageSentAt: {
      type: Date,
      default: null,
    },

    // Set by "Cancel Pass" (Guest List -> Action): when the pass of an
    // approved guest was cancelled, and when the "your pass has been
    // cancelled" WhatsApp message was delivered (null = not delivered).
    passCancelledAt: {
      type: Date,
      default: null,
    },

    passCancelMessageSentAt: {
      type: Date,
      default: null,
    },

    // The booking (pass) that was cancelled. Kept so "Approve Pass" can bring
    // back the SAME pass (same QR) and send it again, instead of making a
    // new one. Cleared when the pass is restored or a new pass is sent.
    passCancelledBookingId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Booking",
      default: null,
    },

    passCancelledEventId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Event",
      default: null,
    },

    // ================= HAMPER =================
    // Approved guests can be added to the Hamper tab (Guest List) and then
    // marked as "sent" once the hamper has been handed over / dispatched.
    inHamper: { type: Boolean, default: false },
    hamperAddedAt: { type: Date, default: null },
    hamperSent: { type: Boolean, default: false },
    hamperSentAt: { type: Date, default: null },

    // ================= ATTENDANCE REMINDER / RSVP =================
    // "Send Reminder" (Guest List -> Approved) sends the WhatsApp template
    // with Yes / No buttons. Each button opens a public page on the
    // website (/rsvp/yes/:token, /rsvp/no/:token) which saves the answer
    // here. See services/rsvp.service.js.
    //   none = reminder sent / not answered yet, yes = coming, no = not coming
    rsvpToken: {
      type: String,
      trim: true,
      default: undefined,
    },

    rsvpStatus: {
      type: String,
      enum: ["none", "yes", "no"],
      default: "none",
    },

    // Event the reminder / answer is for.
    rsvpEventId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Event",
      default: null,
    },

    rsvpReminderSentAt: {
      type: Date,
      default: null,
    },

    rsvpReminderCount: {
      type: Number,
      default: 0,
    },

    // Last time the guest tapped Yes / No (updated again if they change it).
    rsvpRespondedAt: {
      type: Date,
      default: null,
    },

    // Soft-delete fields, same pattern already used on Event/Booking
    // (isDeleted / deletedAt / deletedBy) — deleting a contact never
    // hard-removes the document.
    isDeleted: {
      type: Boolean,
      default: false,
    },

    deletedAt: {
      type: Date,
      default: null,
    },

    deletedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Admin",
      default: null,
    },

    // Tracks which Admin created this contact, same convention as
    // Event.createdBy / TicketType.createdBy / Booking.createdBy.
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Admin",
      default: null,
    },
  },
  {
    timestamps: true,
  }
);

// ================= REFERENCE NORMALIZATION =================
// Trims every value and drops case-insensitive duplicates, keeping the
// first occurrence's original casing — e.g. ["a", " A ", "b", "a"]
// becomes ["a", "b"]. Also drops empty/non-string entries (defensive;
// the validator already rejects these at the request layer).
// A value like "Ramesh & Suresh" / "Ramesh/Suresh" / "Ramesh-Suresh" is split
// at the special character (& / -) into separate references - see
// utils/splitReferences.js.
function normalizeReferences(list) {
  if (!Array.isArray(list)) return [];

  return toReferenceList(list);
}

// Exposed so later services/controllers normalize/compare references
// the exact same way, instead of reimplementing this lowercase-trim
// logic ad hoc (e.g. when cross-matching "a" across Karan's and
// Mahesh's contacts).
contactSchema.statics.normalizeReferences = normalizeReferences;
contactSchema.statics.normalizeReferenceKey = (value) =>
  String(value || "").trim().toLowerCase();

// Applies on every direct save (create, or `contact.save()` after
// mutating `.references` in memory).
contactSchema.pre("save", function (next) {
  if (this.isModified("references")) {
    this.references = normalizeReferences(this.references);
  }
  next();
});

// Also normalize on findOneAndUpdate / findByIdAndUpdate — same
// dual-hook convention already used by User.model.js for its
// `password` field (hash on save AND on findOneAndUpdate).
contactSchema.pre("findOneAndUpdate", function (next) {
  const update = this.getUpdate() || {};
  const references = update.references || (update.$set && update.$set.references);

  if (!references) return next();

  const normalized = normalizeReferences(references);

  if (update.references) {
    update.references = normalized;
  } else {
    update.$set.references = normalized;
  }

  this.setUpdate(update);
  next();
});

// ================= INDEXES =================
// Common "list active, non-deleted contacts" query.
contactSchema.index({ isDeleted: 1, status: 1 });
contactSchema.index({ approvalStatus: 1 });
contactSchema.index({ formLinkId: 1 });
contactSchema.index({ editionEventId: 1 });
contactSchema.index({ rsvpEventId: 1, rsvpStatus: 1 });
// Sparse unique: only contacts that were sent a reminder have a token.
contactSchema.index({ rsvpToken: 1 }, { unique: true, sparse: true });

// Lookup/search by name.
contactSchema.index({ fullName: 1 });

// WhatsApp number must be unique among ACTIVE (non-soft-deleted)
// contacts only — a partial unique index so a soft-deleted contact's
// number never blocks the same number being reused on a new contact,
// while still preventing two active contacts from sharing one number.
// The SAME number may be a guest in different editions (events) - e.g. a
// Parv 6 guest who is invited again to the next event. It must be unique only
// WITHIN one edition. (The old index on whatsappNumber alone is dropped on
// start-up by config/db.js.)
contactSchema.index(
  { whatsappNumber: 1, editionEventId: 1 },
  { unique: true, partialFilterExpression: { isDeleted: false } }
);

// Filter contacts by category.
contactSchema.index({ companyCategory: 1 });
contactSchema.index({ professionCategory: 1 });

// Case-insensitive lookup of "which contacts have reference X" (the
// Karan/Mahesh example above). Mongo indexes array fields element-by-
// element automatically (a multikey index), and the collation here
// makes that lookup case-insensitive — same collation settings as
// CompanyCategory.model.js's unique `name` index, for consistency.
contactSchema.index(
  { references: 1 },
  { collation: { locale: "en", strength: 2 } }
);

module.exports = mongoose.model("Contact", contactSchema);