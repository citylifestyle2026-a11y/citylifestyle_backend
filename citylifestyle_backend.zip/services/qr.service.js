const jwt = require("jsonwebtoken");

const BookingTicket = require("../models/bookingTicket.model");
const Booking = require("../models/booking.model");
const Event = require("../models/event.model");
const AppError = require("../utils/AppError");
const faceService = require("./faceRecognition.service");

// TEMPORARY (testing only): set QR_TEST_MODE=true in the server env to skip
// the "event inactive" / "event ended" checks while testing scans.
// Remove the variable (or set it to false) before the real event.
const QR_TEST_MODE = String(process.env.QR_TEST_MODE || "").toLowerCase() === "true";

// ================= WHAT A SCANNED QR CAN CONTAIN =================
// NEW single-QR pass (public /ticket?qr=<id> page): the QR encodes ONLY the
// short 8-digit Invitation ID. That keeps the QR a small, low-density
// (21x21) code that scans instantly from any phone screen, instead of the
// long signed token, which produced a dense, hard-to-scan QR.
// OLD tickets (and the per-ticket flow): the QR encodes the signed JWT.
//
// Both resolve to a ticketNumber. For an Invitation ID that is the
// booking's primary (first) ticket - the same ticket the pass page
// represents. Everything after this (status checks, group check-in of all
// guests, the response DTO) is unchanged, and the DTO still returns that
// ticket's qrToken, so the scanner's automatic check-in call keeps working.
const INVITATION_ID_REGEX = /^\d{8}$/;

const resolveTicketNumber = async (qrValue) => {
  const value = String(qrValue || "").trim();

  if (INVITATION_ID_REGEX.test(value)) {
    const booking = await Booking.findOne({ invitationId: value }).select("_id");

    if (!booking) {
      // Valid-looking Invitation ID, but this server has no pass with it
      // (deleted pass, or the pass was sent from a different server /
      // database than the one this scanner is connected to).
      throw new AppError(
        `Pass not found for Invitation ID ${value}. It may be deleted, or sent from a different server.`,
        404
      );
    }

    const primaryTicket = await BookingTicket.findOne({ bookingId: booking._id })
      .sort({ createdAt: 1, _id: 1 })
      .select("ticketNumber");

    if (!primaryTicket) {
      throw new AppError("QR ticket not found.", 404);
    }

    return primaryTicket.ticketNumber;
  }

  try {
    return jwt.verify(value, process.env.JWT_SECRET).ticketNumber;
  } catch (error) {
    throw new AppError("Invalid or expired QR code.", 401);
  }
};
 // verfiy qr
const verifyQr = async ({ qrToken }) => {
  // ==========================
  // 1. Verify QR (Invitation ID or signed token)
  // ==========================
  const payload = { ticketNumber: await resolveTicketNumber(qrToken) };

  // ==========================
  // 2. Find Ticket
  // ==========================
  const ticket = await BookingTicket.findOne({
    ticketNumber: payload.ticketNumber,
  })
    .populate({
      path: "bookingId",
      select:
        "bookingNumber name mobileNumber email quantity amount discount isDeleted entryMode invitationId",
    })
    .populate({
      path: "eventId",
      select:
        "title venueName address startDateTime endDateTime isActive",
    })
    .populate({
      path: "ticketTypeId",
      select: "ticketName amount",
    });

  if (!ticket) {
    throw new AppError("QR ticket not found.", 404);
  }

  // ==========================
  // 3. Booking Validation
  // ==========================
  if (!ticket.bookingId) {
    throw new AppError("Booking not found.", 404);
  }

  if (ticket.bookingId.isDeleted) {
    throw new AppError("This booking has been cancelled.", 400);
  }

  // ==========================
  // 4. Ticket Validation
  // ==========================
  if (ticket.status === "Cancelled") {
    throw new AppError("This ticket has been cancelled.", 400);
  }

  // Single-QR pass: the first ticket may be "Used" (some guests already
  // entered) while other guests are still to come - that is still valid.
  const isGroupPass = ticket.bookingId.entryMode === "single_qr";
  let guestsLeft = 0;
  let guestsEntered = 0;

  if (isGroupPass) {
    [guestsLeft, guestsEntered] = await Promise.all([
      BookingTicket.countDocuments({ bookingId: ticket.bookingId._id, status: "Active" }),
      BookingTicket.countDocuments({ bookingId: ticket.bookingId._id, status: "Used" }),
    ]);
  }

  if (ticket.status === "Used" && guestsLeft === 0) {
    throw new AppError("This ticket has already been used.", 400);
  }

  // ==========================
  // 5. Event Validation
  // ==========================
  if (!ticket.eventId) {
    throw new AppError("Event not found.", 404);
  }

  if (!QR_TEST_MODE && !ticket.eventId.isActive) {
    throw new AppError("This event is inactive.", 400);
  }

  if (!QR_TEST_MODE && new Date() > new Date(ticket.eventId.endDateTime)) {
    throw new AppError("This event has already ended.", 400);
  }

  // ==========================
  // 6. Return Response DTO
  // ==========================
  return {
    bookingId: ticket.bookingId._id,
    bookingNumber: ticket.bookingNumber,
    ticketId: ticket._id,
    ticketNumber: ticket.ticketNumber,
    // Group pass with guests still to come is "Active" even if its first
    // ticket was already used by an earlier partial entry.
    status: isGroupPass && guestsLeft > 0 ? "Active" : ticket.status,
    isRegistered: ticket.isRegistered,
     qrToken: ticket.qrToken, 
    attendee: ticket.attendee,

    // NEW single-QR flow: this one QR admits the WHOLE booking.
    isGroupEntry: ticket.bookingId.entryMode === "single_qr",
    guests: ticket.bookingId.quantity,
    // Partial entry: guests still to enter / already entered on this pass.
    remaining: isGroupPass ? guestsLeft : 1,
    alreadyEntered: isGroupPass ? guestsEntered : 0,
    totalGuests: isGroupPass ? guestsLeft + guestsEntered : 1,

    booking: {
      name: ticket.bookingId.name,
      mobileNumber: ticket.bookingId.mobileNumber,
      invitationId: ticket.bookingId.invitationId || null,
      quantity: ticket.bookingId.quantity,
      amount: ticket.bookingId.amount,
      discount: ticket.bookingId.discount,
    },

    event: {
      id: ticket.eventId._id,
      title: ticket.eventId.title,
      venueName: ticket.eventId.venueName,
      address: ticket.eventId.address,
      startDateTime: ticket.eventId.startDateTime,
      endDateTime: ticket.eventId.endDateTime,
    },

    ticketType: {
      id: ticket.ticketTypeId._id,
      ticketName: ticket.ticketTypeId.ticketName,
      amount: ticket.ticketTypeId.amount,
    },
  };
};
// ================= CHECK-IN QR =================
// `guests` (optional): how many people are entering NOW on a single-QR pass.
//  - pass with 1 guest left            -> that guest is checked in, no question
//  - pass with 2+ guests left, no count -> NOTHING is checked in; the response
//    has needsGuestCount:true so the scanner can ask "how many came?"
//    (ONLY when the scanner sends askGuests:true. An OLD scanner app that does
//    not know about the question keeps the old behaviour: all remaining guests
//    are admitted in one scan, instead of showing a false green with nobody
//    checked in.)
//  - pass with 2+ guests left, count given -> exactly that many are checked in;
//    the rest stay "Active", so the SAME QR works again later for them.
const checkInQr = async ({ qrToken, scannedBy, guests, askGuests }) => {
  // 1. Verify QR (Invitation ID or signed token)
  const payload = { ticketNumber: await resolveTicketNumber(qrToken) };

  // 2. Find Ticket
  // The frontend now calls check-in automatically right after verify (no
  // "Allow Entry" click in between), so this response needs to be
  // self-sufficient — populated the same way verifyQr does — instead of
  // only returning the bare ticketId/status it used to. This does not
  // add any new validation; it only fetches the related documents needed
  // to build a complete response DTO.
  const ticket = await BookingTicket.findOne({
    ticketNumber: payload.ticketNumber,
  })
    .populate({
      path: "bookingId",
      select:
        "bookingNumber name mobileNumber email quantity amount discount isDeleted entryMode invitationId",
    })
    .populate({
      path: "eventId",
      select:
        "title venueName address startDateTime endDateTime isActive",
    })
    .populate({
      path: "ticketTypeId",
      select: "ticketName amount",
    });

  if (!ticket) {
    throw new AppError("Ticket not found.", 404);
  }

  // 3. Validation - the same rules verifyQr applies. The scanner app only
  // calls check-in, so without these a cancelled booking, an inactive event
  // or an event that is already over would still be let in.
  if (!ticket.bookingId) {
    throw new AppError("Booking not found.", 404);
  }

  if (ticket.bookingId.isDeleted) {
    throw new AppError("This booking has been cancelled.", 400);
  }

  const isGroupEntry = ticket.bookingId?.entryMode === "single_qr";
  let activeCount = 0;
  let usedCount = 0;

  if (isGroupEntry) {
    // Single-QR pass: the pass is valid as long as ANY guest is still
    // "Active" - the QR's own (first) ticket may already be "Used".
    [activeCount, usedCount] = await Promise.all([
      BookingTicket.countDocuments({ bookingId: ticket.bookingId._id, status: "Active" }),
      BookingTicket.countDocuments({ bookingId: ticket.bookingId._id, status: "Used" }),
    ]);

    // Shows in the server log whether the scanner app is the NEW one (it sends
    // askGuests:true). If this says askGuests=false, the phone still has the old APK.
    console.log(
      `[check-in] pass ${ticket.bookingId.invitationId || ticket.bookingNumber}: ` +
        `active=${activeCount} used=${usedCount} askGuests=${!!askGuests} guests=${guests ?? "-"}`
    );

    if (activeCount === 0) {
      throw new AppError(
        usedCount > 0
          ? `This ticket has already been checked in. All ${usedCount} guest${usedCount === 1 ? "" : "s"} have entered.`
          : "This ticket has been cancelled.",
        400
      );
    }
  } else {
    if (ticket.status === "Used") {
      throw new AppError("This ticket has already been checked in.", 400);
    }

    if (ticket.status === "Cancelled") {
      throw new AppError("This ticket has been cancelled.", 400);
    }
  }

  if (!ticket.eventId) {
    throw new AppError("Event not found.", 404);
  }

  if (!QR_TEST_MODE && !ticket.eventId.isActive) {
    throw new AppError("This event is inactive.", 400);
  }

  // (worded without "already" so the app does not show it as "ticket used")
  if (!QR_TEST_MODE && ticket.eventId.endDateTime && new Date() > new Date(ticket.eventId.endDateTime)) {
    throw new AppError("This event has ended.", 400);
  }

  // 4. Update Ticket(s)
  let guestsCheckedIn = 1;
  let guestsLeft = 0;

  if (isGroupEntry) {
    // Single-QR flow with PARTIAL entry: the scanner says how many people
    // are entering now (`guests`); only that many tickets become "Used".
    const requested = Number(guests);
    const hasCount = Number.isInteger(requested) && requested >= 1;

    // 2+ guests still to enter and nobody said how many -> ask, change nothing.
    if (activeCount > 1 && !hasCount && askGuests) {
      return {
        needsGuestCount: true,
        isGroupEntry: true,
        remaining: activeCount,
        alreadyEntered: usedCount,
        totalGuests: activeCount + usedCount,
        guests: 0,
        booking: {
          name: ticket.bookingId.name,
          mobileNumber: ticket.bookingId.mobileNumber,
          invitationId: ticket.bookingId.invitationId || null,
          quantity: ticket.bookingId.quantity,
        },
        attendee: ticket.attendee,
      };
    }

    // Only one guest left -> that one guest is checked in, no question.
    const toCheckIn = activeCount === 1 ? 1 : hasCount ? requested : activeCount;

    if (!Number.isInteger(toCheckIn) || toCheckIn < 1 || toCheckIn > activeCount) {
      throw new AppError(
        `Only ${activeCount} guest${activeCount === 1 ? " is" : "s are"} left on this pass. Choose between 1 and ${activeCount}.`,
        400
      );
    }

    // One atomic update per guest, so two phones scanning the same pass at
    // the same moment can never admit more people than the pass has.
    const scannedAt = new Date();
    let done = 0;
    for (let i = 0; i < toCheckIn; i += 1) {
      const marked = await BookingTicket.findOneAndUpdate(
        { bookingId: ticket.bookingId._id, status: "Active" },
        { $set: { status: "Used", scannedAt, scannedBy } },
        { sort: { createdAt: 1, _id: 1 } }
      );
      if (!marked) break;
      done += 1;
    }

    if (done === 0) {
      throw new AppError("This ticket has already been checked in.", 400);
    }

    guestsCheckedIn = done;
    guestsLeft = Math.max(activeCount - done, 0);
    ticket.status = guestsLeft === 0 ? "Used" : "Active";
    ticket.scannedAt = scannedAt;
    ticket.scannedBy = scannedBy;
  } else {
    // OLD flow (one ticket = one QR = one scan).
    // One ATOMIC update (only while the ticket is not yet Used / Cancelled), so two
    // phones scanning the same QR at the same moment can never both be let in:
    // the second one finds nothing to update and is told it was already used.
    const scannedAt = new Date();
    const marked = await BookingTicket.findOneAndUpdate(
      { _id: ticket._id, status: { $nin: ["Used", "Cancelled"] } },
      { $set: { status: "Used", scannedAt, scannedBy } }
    );

    if (!marked) {
      throw new AppError("This ticket has already been checked in.", 400);
    }

    ticket.status = "Used";
    ticket.scannedAt = scannedAt;
    ticket.scannedBy = scannedBy;
  }

  // 5. Return Response DTO
  // Mirrors verifyQr's DTO shape below so the frontend gets the same
  // complete attendee/ticket/event/booking details — including
  // attendee.profileImage (already stored on BookingTicket, not
  // generated here) — straight from the automatic check-in call.
  return {
    bookingId: ticket.bookingId?._id ?? null,
    bookingNumber: ticket.bookingNumber,
    ticketId: ticket._id,
    ticketNumber: ticket.ticketNumber,
    status: ticket.status,
    isRegistered: ticket.isRegistered,
    scannedAt: ticket.scannedAt,
    attendee: ticket.attendee,
    isGroupEntry,
    guests: isGroupEntry ? guestsCheckedIn : 1,
    // Single-QR pass: how many are still to come on this same QR.
    remaining: isGroupEntry ? guestsLeft : 0,
    alreadyEntered: isGroupEntry ? usedCount : 0,
    totalGuests: isGroupEntry ? activeCount + usedCount : 1,

    booking: ticket.bookingId
      ? {
          name: ticket.bookingId.name,
          mobileNumber: ticket.bookingId.mobileNumber,
          invitationId: ticket.bookingId.invitationId || null,
          quantity: ticket.bookingId.quantity,
          amount: ticket.bookingId.amount,
          discount: ticket.bookingId.discount,
        }
      : null,

    event: ticket.eventId
      ? {
          id: ticket.eventId._id,
          title: ticket.eventId.title,
          venueName: ticket.eventId.venueName,
          address: ticket.eventId.address,
          startDateTime: ticket.eventId.startDateTime,
          endDateTime: ticket.eventId.endDateTime,
        }
      : null,

    ticketType: ticket.ticketTypeId
      ? {
          id: ticket.ticketTypeId._id,
          ticketName: ticket.ticketTypeId.ticketName,
          amount: ticket.ticketTypeId.amount,
        }
      : null,
  };
};

// ================= UNDO / EDIT CHECK-IN =================
// Staff tapped the wrong number (e.g. allowed 2 guests instead of 1).
// This puts the most recently checked-in guest(s) of the pass back to
// "Active" so the SAME QR can be scanned again with the correct count.
// Safety: only entries scanned within the last QR_UNDO_WINDOW_MINUTES
// (default 15) can be reverted, so old entries cannot be tampered with.
const UNDO_WINDOW_MS =
  (Number(process.env.QR_UNDO_WINDOW_MINUTES) || 15) * 60 * 1000;

const undoCheckInQr = async ({ qrToken, guests }) => {
  const ticketNumber = await resolveTicketNumber(qrToken);

  const ticket = await BookingTicket.findOne({ ticketNumber }).populate({
    path: "bookingId",
    select: "entryMode isDeleted invitationId bookingNumber",
  });

  if (!ticket || !ticket.bookingId) {
    throw new AppError("Ticket not found.", 404);
  }

  if (ticket.bookingId.isDeleted) {
    throw new AppError("This booking has been cancelled.", 400);
  }

  const isGroupEntry = ticket.bookingId.entryMode === "single_qr";
  const since = new Date(Date.now() - UNDO_WINDOW_MS);

  // Guests that can still be reverted (recent "Used" tickets, newest first).
  const filter = isGroupEntry
    ? { bookingId: ticket.bookingId._id, status: "Used", scannedAt: { $gte: since } }
    : { _id: ticket._id, status: "Used", scannedAt: { $gte: since } };

  const recent = await BookingTicket.find(filter)
    .sort({ scannedAt: -1, _id: -1 })
    .select("_id");

  if (recent.length === 0) {
    throw new AppError(
      `Nothing to undo. Only entries from the last ${Math.round(UNDO_WINDOW_MS / 60000)} minutes can be edited.`,
      400
    );
  }

  const requested = Number(guests);
  const toUndo = Number.isInteger(requested) && requested >= 1 ? requested : recent.length;

  if (toUndo > recent.length) {
    throw new AppError(
      `Only ${recent.length} recent guest${recent.length === 1 ? "" : "s"} can be undone.`,
      400
    );
  }

  let undone = 0;
  for (let i = 0; i < toUndo; i += 1) {
    const reverted = await BookingTicket.findOneAndUpdate(
      { _id: recent[i]._id, status: "Used" },
      { $set: { status: "Active" }, $unset: { scannedAt: 1, scannedBy: 1 } }
    );
    if (reverted) undone += 1;
  }

  const [remaining, alreadyEntered] = await Promise.all([
    BookingTicket.countDocuments({ bookingId: ticket.bookingId._id, status: "Active" }),
    BookingTicket.countDocuments({ bookingId: ticket.bookingId._id, status: "Used" }),
  ]);

  console.log(
    `[undo-check-in] pass ${ticket.bookingId.invitationId || ticket.bookingId.bookingNumber}: ` +
      `undone=${undone} remaining=${remaining} entered=${alreadyEntered}`
  );

  return {
    undone,
    remaining,
    alreadyEntered,
    totalGuests: remaining + alreadyEntered,
    isGroupEntry,
  };
};

// ================= FACE SCAN =================
// Second way to let a person in, next to the QR: the scanner app sends the
// 128-number face fingerprint of the face in front of the camera. It is
// compared with the fingerprints saved when each attendee registered their
// photo (see faceRecognition.service.js). Nothing is checked in here - the
// app shows the matched person to the staff, who confirm, and only then
// faceCheckInQr() marks that exact ticket as Used.
const toFaceDto = (ticket) => ({
  ticketId: ticket._id,
  ticketNumber: ticket.ticketNumber,
  status: ticket.status,
  scannedAt: ticket.scannedAt || null,
  attendee: {
    name: ticket.attendee?.name || "",
    mobileNumber: ticket.attendee?.mobileNumber || "",
    profileImage: ticket.attendee?.profileImage || "",
  },
  booking: ticket.bookingId
    ? {
        name: ticket.bookingId.name,
        invitationId: ticket.bookingId.invitationId || null,
        quantity: ticket.bookingId.quantity,
      }
    : null,
  event: ticket.eventId ? { id: ticket.eventId._id, title: ticket.eventId.title } : null,
  ticketType: ticket.ticketTypeId ? { ticketName: ticket.ticketTypeId.ticketName } : null,
});

const matchFace = async ({ descriptor }) => {
  if (!faceService.isValidDescriptor(descriptor)) {
    throw new AppError("Invalid face data. Please scan the face again.", 400);
  }

  // Only people of events that are running / upcoming can be matched.
  const events = await Event.find({
    isActive: true,
    endDateTime: { $gte: new Date() },
  }).select("_id");

  if (events.length === 0) {
    return { matched: false, reason: "no_active_event" };
  }

  const candidates = await BookingTicket.find({
    eventId: { $in: events.map((e) => e._id) },
    isRegistered: true,
    status: { $in: ["Active", "Used"] },
    "attendee.faceDescriptor.0": { $exists: true },
  })
    .select("+attendee.faceDescriptor ticketNumber status scannedAt attendee eventId ticketTypeId bookingId")
    .populate({ path: "bookingId", select: "name quantity invitationId isDeleted" })
    .populate({ path: "eventId", select: "title" })
    .populate({ path: "ticketTypeId", select: "ticketName" })
    .lean();

  const enrolled = candidates.filter((t) => t.bookingId && !t.bookingId.isDeleted);

  if (enrolled.length === 0) {
    return { matched: false, reason: "no_faces_enrolled" };
  }

  let best = null;
  let bestDistance = Infinity;
  for (const ticket of enrolled) {
    const d = faceService.distance(descriptor, ticket.attendee.faceDescriptor);
    if (d < bestDistance) {
      bestDistance = d;
      best = ticket;
    }
  }

  if (!best || bestDistance > faceService.MATCH_THRESHOLD) {
    return { matched: false, reason: "no_match" };
  }

  return {
    matched: true,
    distance: Number(bestDistance.toFixed(3)),
    // Easy label for the staff screen.
    level: bestDistance <= 0.35 ? "high" : bestDistance <= 0.45 ? "good" : "check",
    alreadyEntered: best.status === "Used",
    ...toFaceDto(best),
  };
};

// Staff confirmed the face match -> mark THAT ticket as Used.
const faceCheckInQr = async ({ ticketId, scannedBy }) => {
  const ticket = await BookingTicket.findById(ticketId)
    .populate({ path: "bookingId", select: "name quantity invitationId isDeleted entryMode" })
    .populate({ path: "eventId", select: "title isActive endDateTime" })
    .populate({ path: "ticketTypeId", select: "ticketName" });

  if (!ticket) throw new AppError("Ticket not found.", 404);
  if (!ticket.bookingId) throw new AppError("Booking not found.", 404);
  if (ticket.bookingId.isDeleted) throw new AppError("This booking has been cancelled.", 400);
  if (ticket.status === "Cancelled") throw new AppError("This ticket has been cancelled.", 400);
  if (ticket.status === "Used") throw new AppError("This ticket has already been checked in.", 400);
  if (!ticket.eventId) throw new AppError("Event not found.", 404);
  if (!QR_TEST_MODE && !ticket.eventId.isActive) throw new AppError("This event is inactive.", 400);
  if (!QR_TEST_MODE && ticket.eventId.endDateTime && new Date() > new Date(ticket.eventId.endDateTime)) {
    throw new AppError("This event has ended.", 400);
  }

  // Atomic: two phones can never let the same person in twice.
  const scannedAt = new Date();
  const marked = await BookingTicket.findOneAndUpdate(
    { _id: ticket._id, status: "Active" },
    { $set: { status: "Used", scannedAt, scannedBy } }
  );
  if (!marked) throw new AppError("This ticket has already been checked in.", 400);

  ticket.status = "Used";
  ticket.scannedAt = scannedAt;

  const isGroupEntry = ticket.bookingId.entryMode === "single_qr";
  const remaining = isGroupEntry
    ? await BookingTicket.countDocuments({ bookingId: ticket.bookingId._id, status: "Active" })
    : 0;

  console.log(
    `[face-check-in] ticket ${ticket.ticketNumber} (${ticket.attendee?.name || "-"}) by ${scannedBy}`
  );

  return {
    ...toFaceDto(ticket),
    isGroupEntry,
    remaining,
    guests: 1,
  };
};

module.exports = {
  verifyQr,
  matchFace,
  faceCheckInQr,
  checkInQr,
  undoCheckInQr,
};