const Booking = require("../models/booking.model");
const Event = require("../models/event.model");
const TicketType = require("../models/ticketType.model");
const Counter = require("../models/counters.model");
const BookingTicket = require("../models/bookingTicket.model");
const generateTicketNumber = require("../utils/generateTicketNumber");
const generateQrToken = require("../utils/generateQrToken");
const generateQrCode = require("../utils/generateQrCode");
const uploadImage = require("../utils/localUpload.util");
const AppError = require("../utils/AppError");
const eventService = require("./event.service");
const whatsappService = require("./whatsapp.service");
const buildRegistrationBodyParams = require("../utils/buildRegistrationBodyParams");
const generateRegistrationToken = require("../utils/generateRegistrationToken");
// NEW single-QR invitation flow (see services/invitation.service.js).
const invitationService = require("./invitation.service");
const generateInvitationId = require("../utils/generateInvitationId");
const {
  normalizeMobileNumber,
  getMobileNumberVariants,
  normalizeMobileSearchTerm,
  toMobileFilterDigits,
  MOBILE_ERROR_MESSAGE,
} = require("../utils/normalizeMobileNumber");
const mongoose = require("mongoose");

// ================= EVENT-WISE BOOKING NUMBER =================
// Was previously a single global counter keyed by year
// (`BOOKING_${year}`), producing e.g. "BK2026000123" shared across every
// event. Now keyed by the event's own `eventId` (`BOOKING_${eventId}`),
// so each event gets its own independent sequence that always starts at
// BK001 and is never shared with, or affected by, any other event —
// including one that has since been deleted by the expiry scheduler,
// since eventId-keyed Counter documents are never touched by that
// scheduler and stay unique forever. Still a single atomic
// findOneAndUpdate $inc/upsert (same pattern as before and as
// generateTicketNumber.js), so two simultaneous bookings for the same
// event can never receive the same number.
const generateBookingNumber = async (eventId, eventCode, session) => {
  const counter = await Counter.findOneAndUpdate(
    { name: `BOOKING_${eventId}` },
    { $inc: { sequence: 1 } },
    {
      new: true,
      upsert: true,
      session
    }
  );

  return `${eventCode}-BK${String(counter.sequence).padStart(3, "0")}`;
};

// ================= OLD FLOW (KEPT, SWITCHABLE) =================
// The function below is the OLD "send registration link over WhatsApp"
// step. It is NOT removed. It runs when
//   BOOKING_NOTIFICATION_MODE=registration_link
// The default mode (qr_invite) sends ONE invitation with ONE QR instead
// -- see services/invitation.service.js and createBooking below.
// ================= SEND REGISTRATION LINK VIA WHATSAPP (BEST-EFFORT) =================
// QR codes continue to be generated exactly as before (see the
// createBooking loop below — untouched), but are intentionally NOT sent
// over WhatsApp anymore. Instead, the existing public registration link
// mechanism (utils/generateRegistrationToken.js / buildRegistrationUrl.js
// via the template's Dynamic URL button — token/URL structure unchanged)
// is sent to the SAME booking.mobileNumber.
//
// Exactly ONE WhatsApp message is sent per booking (not one per ticket):
// the button param uses the FIRST ticket's registrationToken. All tickets
// created by this booking share the same bookingId, and the public
// registration API (getRegistrationDetails) resolves that ticket's
// bookingId back to the existing Booking.quantity, so opening this single
// link is enough for the registration page/API to know the full booking
// quantity — no new field, token, or URL shape is introduced.
//
// For quantity = 1 this is identical to the previous per-ticket loop
// (exactly one ticket, exactly one message). For quantity > 1, this
// avoids sending multiple different links (and multiple messages) for
// what is, from the customer's point of view, a single registration.
//
// Runs only after the booking + ticket transaction has already
// committed, and is never allowed to fail the booking: any failure
// (missing Chatbox config, Chatbox API error, network error) is caught
// and only logged, never rethrown, so a WhatsApp outage can never turn a
// successful booking into a failed request.
const sendRegistrationWhatsAppNotification = async (booking, event, tickets) => {
  if (!Array.isArray(tickets) || tickets.length === 0) {
    return;
  }

  const templateName =
    process.env.CHATBOX_REGISTRATION_TEMPLATE_NAME || "event_registration_link";
  const templateLanguage =
    process.env.CHATBOX_REGISTRATION_TEMPLATE_LANGUAGE || "en";

  const bodyParams = buildRegistrationBodyParams({ booking, event });

  // Same token every ticket of this booking would otherwise be sent
  // individually for — using the first one is sufficient since the
  // registration details API resolves quantity from the booking, not
  // from which specific ticket the token points to.
  const primaryTicket = tickets[0];

  try {
    await whatsappService.sendTemplateMessage({
      phone: booking.mobileNumber,
      templateName,
      languageCode: templateLanguage,
      bodyParams,
      buttonParam: buildRegistrationBodyParams.buildRegistrationButtonParam(primaryTicket),
    });
  } catch (error) {
    console.error(
      `WhatsApp registration notification failed for booking ${booking.bookingNumber}:`,
      error
    );
  }
};

// post api
// `createdBy` is now accepted as its own argument (set by the controller
// from req.user.id) rather than being expected inside `data` — mirrors
// eventService.createEvent(data, file, adminId) and
// ticketTypeService.createTicketType(data, createdBy).
const createBooking = async (data, createdBy) => {
  const session = await mongoose.startSession();

  try {
    session.startTransaction();

    const {
      eventId,
      ticketTypeId,
      quantity,
      amount,
      name,
      mobileNumber,
      email,
      discount,
      remark,
      companyName,
      allowDuplicate,
    } = data;

    // ================= MOBILE NUMBER (WITH / WITHOUT 91) =================
    // The POST /bookings/create route already validates + normalises this
    // (validators/booking.validator.js), but the CSV import calls
    // createBooking directly and never goes through that validator — so
    // the same rule is enforced here too. Accepts 9876543210 /
    // 919876543210 / +91 98765 43210 and always stores "91XXXXXXXXXX".
    const normalizedMobileNumber = normalizeMobileNumber(mobileNumber);
    if (!normalizedMobileNumber) {
      throw new AppError(MOBILE_ERROR_MESSAGE, 400);
    }

    // ================= DUPLICATE BOOKING WARNING (SAME MOBILE NUMBER) =================
    // The SAME mobile number already has a booking for this event +
    // ticket type -> stop here (409) before any ticket is deducted or any
    // QR / WhatsApp link is created. The name may repeat; only the mobile
    // number must be different. See findDuplicateBooking below.
    //
    // allowDuplicate === true ("Book Anyway" button in CreateBookingModal)
    // skips ONLY this check. The CSV import never sets it, so CSV rows
    // that are duplicates are always skipped.
    const existingDuplicate =
      allowDuplicate === true || allowDuplicate === "true"
        ? null
        : await findDuplicateBooking({
            eventId,
            ticketTypeId,
            mobileNumber: normalizedMobileNumber,
          });
    if (existingDuplicate) {
      throw new AppError(
        `Duplicate booking — this mobile number (${mobileNumber}) already has booking ${existingDuplicate.bookingNumber} (under the name "${existingDuplicate.name}") for this event & ticket type. No new booking was created.`,
        409
      );
    }

    const bookingQuantity = Number(quantity);
    const bookingAmount = Number(amount);
    const discountAmount = Number(discount || 0);
    if (bookingQuantity <= 0) {
      throw new AppError("Invalid booking quantity", 400);
    }

    if (bookingAmount < 0) {
      throw new AppError("Invalid booking amount", 400);
    }
    const event = await Event.findById(eventId).session(session);
    if (!event) {
      throw new AppError("Event not found", 404);
    }
    if (!event.isActive) {
      throw new AppError(
        "Booking cannot be created because the event is inactive.",
        400
      );
    }
    if (new Date(event.endDateTime) < new Date()) {
      throw new AppError(
        "Booking cannot be created because the event has expired.",
        400
      );
    }
    const ticketType = await TicketType.findOneAndUpdate(
      {
        _id: ticketTypeId,
        eventId: eventId,
        isDeleted: false,
        availableCount: {
          $gte: bookingQuantity
        }
      },
      {
        $inc: {
          availableCount: -bookingQuantity
        }
      },
      {
        new: true,
        session
      }
    );

    if (!ticketType) {
      throw new AppError("Ticket not available", 400);
    }

    const expectedAmount =
      (ticketType.amount * bookingQuantity) - discountAmount;

    if (bookingAmount !== expectedAmount) {
      throw new AppError(
        `Invalid booking amount. Expected amount is ${expectedAmount}`,
        400
      );
    }

    const eventCode = await eventService.getOrCreateEventCode(event, session);
    const bookingNumber = await generateBookingNumber(
      event._id,
      eventCode,
      session
    );

    // ================= PASS DATE =================
    // TicketType's date field is `allowDates` — an array, not a single
    // `allowDate`. Since CreateBookingModal has no date-selection UI (and
    // isn't meant to gain one), there's no way for the booking itself to
    // indicate which of possibly several allowDates this ticket is for.
    // The first date in the array is used as the deterministic Pass Date
    // for every ticket this booking generates. If a ticket type only ever
    // has one allowDate in practice, this is exactly that date; if it can
    // genuinely have several, this is a real business-rule assumption —
    // see the accompanying summary.
    const passDate =
      Array.isArray(ticketType.allowDates) && ticketType.allowDates.length > 0
        ? ticketType.allowDates[0]
        : null;

    // ================= NEW: SINGLE QR INVITATION =================
    // qr_invite mode: this booking gets ONE 8-digit invitationId and
    // entryMode "single_qr" (one QR for all `quantity` guests).
    // registration_link mode (OLD flow): both stay unset/"per_ticket".
    const useQrInvite = invitationService.isQrInviteMode();
    const invitationId = useQrInvite ? await generateInvitationId(session) : undefined;

    const booking = await Booking.create(
      [
        {
          bookingNumber,
          ...(useQrInvite ? { invitationId, entryMode: "single_qr" } : {}),
          eventId,
          ticketTypeId,
          quantity: bookingQuantity,
          amount: bookingAmount,
          name,
          mobileNumber: normalizedMobileNumber,
          email,
          discount: discountAmount,
          remark,
          companyName: (companyName || "").trim(),
          createdBy
        }
      ],
      { session }
    );

    const bookingTickets = [];

    for (let i = 0; i < bookingQuantity; i++) {
      // Generate Ticket Number
      const ticketNumber = await generateTicketNumber(
        event._id,
        eventCode,
        session
      );

      // Generate JWT Token
      const qrToken = generateQrToken({
        ticketNumber,
      });

      // Generate QR Buffer
      const qrBuffer = await generateQrCode(qrToken);

      // Save QR image to local disk storage
      const qrUpload = await uploadImage(
        qrBuffer,
        "event-management/qr-codes",
        "image",
        { format: "png" }
      );

      // ================= REGISTRATION TOKEN =================
      // Generated with a pre-assigned _id so the token can identify this
      // exact BookingTicket from the moment it's created -- one unique
      // token per ticket, persisted on the ticket itself (registrationToken)
      // so a later WhatsApp resend reuses this same token instead of
      // minting a new one. Does not touch/replace qrToken, which remains
      // exclusively for the existing QR/entry-scan flow.
      const ticketId = new mongoose.Types.ObjectId();
      const registrationToken = generateRegistrationToken(ticketId);

      bookingTickets.push({
        _id: ticketId,
        bookingId: booking[0]._id,
        eventId,
        ticketTypeId,
        bookingNumber: booking[0].bookingNumber,
        ticketNumber,
        qrToken,
        qrImage: qrUpload.url,
        qrImagePublicId: qrUpload.public_id,
        status: "Active",
        passDate,
        registrationToken,
      });
    }

    const insertedTickets = await BookingTicket.insertMany(
      bookingTickets,
      { session }
    );

    await session.commitTransaction();

    // ================= WHATSAPP REGISTRATION NOTIFICATION (NON-BLOCKING) =================
    // QR codes were generated above exactly as before, but are NOT sent
    // over WhatsApp anymore (see sendRegistrationWhatsAppNotification for
    // details). Only the public registration link is sent, to the same
    // booking.mobileNumber, after the transaction has already committed —
    // so a WhatsApp failure can never roll back or fail an
    // already-successful booking. The response shape below is unchanged.
    if (useQrInvite) {
      // NEW: ONE WhatsApp invitation (with the single QR link) per booking,
      // whether quantity is 1, 2, 3, 4, 5 ... Best-effort, never throws.
      await invitationService.sendInvitationBestEffort(booking[0], event);
    } else {
      // OLD flow (BOOKING_NOTIFICATION_MODE=registration_link): unchanged.
      await sendRegistrationWhatsAppNotification(
        booking[0],
        event,
        insertedTickets
      );
    }

    return {
      booking: booking[0],
      tickets: insertedTickets,
      totalTickets: insertedTickets.length,
    };

  } catch (error) {
    console.error("Create Booking Error:", error);

    if (session.inTransaction()) {
      await session.abortTransaction();
    }

    throw error;
  } finally {
    await session.endSession();
  }
};

// ================= BULK IMPORT BOOKINGS FROM CSV =================
// Parses the uploaded CSV buffer with ExcelJS's built-in CSV reader (no
// new dependency needed — exceljs is already used for exportBookings
// below), then creates one booking per data row by calling the exact
// same createBooking(data, createdBy) above — line by line, in order,
// awaited one at a time (not Promise.all) so two rows never race each
// other for the same ticketType.availableCount, and so a later row's
// failure never affects an earlier row's already-committed booking.
//
// Since each row goes through createBooking unchanged, every existing
// createBooking behavior — the transaction, availableCount decrement,
// amount validation, ticket/QR generation, and the "send the public
// registration link over WhatsApp" step (sendRegistrationWhatsAppNotification)
// — happens exactly the same way for each row as it does for a single
// manual booking. Nothing about createBooking itself is modified.
//
// Expected CSV header row (case-insensitive, order-independent):
//   Either eventId OR eventName (event's exact title) — not both required
//   Either ticketTypeId OR ticketTypeName (ticket's exact name within that event)
//   quantity, amount, name, mobileNumber, email, discount, remark
//
// eventId/ticketTypeId (raw Mongo ObjectIds) are still supported and take
// priority when present — but most admins don't have those IDs handy, so
// eventName/ticketTypeName (looked up below in resolveEventAndTicketType)
// let the CSV be filled in with the same Event/Ticket names shown on the
// Booking/Event pages instead.
//
// A row that fails (bad data, sold out, wrong amount, name not found,
// etc.) is recorded with its error and processing continues with the
// next row — one bad row must never abort the rows before or after it.
const REQUIRED_CSV_COLUMNS = [
  "quantity",
  "amount",
  "name",
  "mobileNumber",
  "companyName",
];
// At least one column from each pair below must be present in the header.
const REQUIRED_COLUMN_ALTERNATIVES = [
  { columns: ["eventId", "eventName"], label: "eventId or eventName" },
  {
    columns: ["ticketTypeId", "ticketTypeName"],
    label: "ticketTypeId or ticketTypeName",
  },
];

// Cell values that mean "blank" in an admin-filled CSV.
const CSV_EMPTY_PLACEHOLDERS = new Set(["", "-", "--", "n/a", "na", "null", "nil"]);

const parseBookingCsvBuffer = async (buffer) => {
  const ExcelJS = require("exceljs");
  const { Readable } = require("stream");

  const workbook = new ExcelJS.Workbook();
  // `map` keeps every cell as the exact text that is in the file. By
  // default ExcelJS turns numeric-looking cells into JS numbers, which
  // silently corrupts mobile numbers Excel wrote in scientific notation
  // ("9.87654E+09" would become the valid-looking 9876540000). As text it
  // fails the mobile-number check with a clear row error instead. Numeric
  // columns (quantity/amount/discount) are converted by Number() later.
  const worksheet = await workbook.csv.read(
    Readable.from(buffer.toString("utf-8")),
    { map: (value) => value }
  );

  const rows = [];
  let headerMap = null;

  worksheet.eachRow((row, rowNumber) => {
    const cellValues = row.values; // 1-indexed, index 0 is unused
    if (rowNumber === 1) {
      headerMap = {};
      cellValues.forEach((cell, idx) => {
        if (cell === null || cell === undefined) return;
        const key = String(cell).trim();
        if (key) headerMap[key.toLowerCase()] = idx;
      });
      return;
    }

    if (!headerMap) return;

    const getValue = (columnName) => {
      const idx = headerMap[columnName.toLowerCase()];
      if (!idx) return undefined;
      const value = cellValues[idx];
      if (value === null || value === undefined) return undefined;
      // ExcelJS can hand back rich-text / formula / hyperlink cells as
      // objects — unwrap to plain text so String(value) never yields
      // "[object Object]".
      const raw =
        typeof value === "object" && value !== null
          ? value.text ?? value.result ?? value.hyperlink ?? ""
          : value;
      const trimmed = String(raw).trim();
      // Admins often type "-" / "N/A" for "nothing here". Treat these
      // placeholders as an empty cell so they never reach Number() (which
      // turns "-" into NaN) or get saved as a real email/remark.
      return CSV_EMPTY_PLACEHOLDERS.has(trimmed.toLowerCase())
        ? undefined
        : trimmed;
    };

    // Skip fully blank rows (trailing newlines etc.)
    const isBlankRow = cellValues.slice(1).every(
      (v) => v === null || v === undefined || String(v).trim() === ""
    );
    if (isBlankRow) return;

    rows.push({
      rowNumber,
      data: {
        eventId: getValue("eventId"),
        eventName: getValue("eventName") || getValue("event"),
        ticketTypeId: getValue("ticketTypeId"),
        ticketTypeName:
          getValue("ticketTypeName") ||
          getValue("ticketType") ||
          getValue("ticketName"),
        quantity: getValue("quantity"),
        amount: getValue("amount"),
        name: getValue("name"),
        mobileNumber: getValue("mobileNumber"),
        email: getValue("email") || "",
        discount: getValue("discount") || 0,
        remark: getValue("remark") || "",
        companyName: getValue("companyName") || "",
      },
    });
  });

  if (!headerMap) {
    throw new AppError("CSV file is empty or missing a header row", 400);
  }

  const missingColumns = REQUIRED_CSV_COLUMNS.filter(
    (col) => !(col.toLowerCase() in headerMap)
  );

  REQUIRED_COLUMN_ALTERNATIVES.forEach(({ columns, label }) => {
    const hasOne = columns.some((col) => col.toLowerCase() in headerMap);
    if (!hasOne) missingColumns.push(label);
  });

  if (missingColumns.length > 0) {
    throw new AppError(
      `CSV is missing required column(s): ${missingColumns.join(", ")}`,
      400
    );
  }

  return rows;
};

// ================= RESOLVE EVENT / TICKET TYPE BY NAME =================
// Lets a CSV row use eventName/ticketTypeName instead of the raw Mongo
// ObjectIds. If eventId/ticketTypeId are already given, they're trusted
// as-is (unchanged, fastest path). Otherwise the event is looked up by
// an exact, case-insensitive match on its title, and the ticket type by
// an exact, case-insensitive match on its ticketName WITHIN that
// resolved event (so the same ticket type name in two different events
// can never be confused with each other). Deleted events/ticket types
// are never matched. Escapes the name before using it in a RegExp so a
// stray regex special character in a CSV cell can't do anything
// unexpected.
const escapeRegExp = (value) =>
  String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

const resolveEventAndTicketType = async (data) => {
  let { eventId, eventName, ticketTypeId, ticketTypeName } = data;

  if (!eventId) {
    if (!eventName) {
      throw new AppError("Event is required (eventId or eventName)", 400);
    }

    const event = await Event.findOne({
      title: new RegExp(`^${escapeRegExp(eventName)}$`, "i"),
      isDeleted: { $ne: true },
    }).select("_id");

    if (!event) {
      throw new AppError(`Event not found for name "${eventName}"`, 404);
    }

    eventId = event._id.toString();
  }

  if (!ticketTypeId) {
    if (!ticketTypeName) {
      throw new AppError(
        "Ticket Type is required (ticketTypeId or ticketTypeName)",
        400
      );
    }

    const ticketType = await TicketType.findOne({
      eventId,
      ticketName: new RegExp(`^${escapeRegExp(ticketTypeName)}$`, "i"),
      isDeleted: false,
    }).select("_id");

    if (!ticketType) {
      throw new AppError(
        `Ticket Type not found for name "${ticketTypeName}" in the resolved event`,
        404
      );
    }

    ticketTypeId = ticketType._id.toString();
  }

  return { ...data, eventId, ticketTypeId };
};

// ================= NORMALISE NUMERIC FIELDS =================
// Validates quantity / discount / amount for one CSV row and returns them
// as real numbers, so a blank or malformed cell produces a clear row-level
// error instead of a NaN reaching Mongoose (which is what caused
// `Cast to Number failed for value "NaN" ... path "amount"` in
// findDuplicateBooking's query).
//
// amount is OPTIONAL in the CSV: createBooking only accepts
// amount === ticketType.amount * quantity - discount anyway, so when the
// cell is blank the one valid value is filled in here. When an amount IS
// given it is used as-is and createBooking still validates it.
const normalizeRowNumbers = async (data) => {
  const quantity = Number(data.quantity);
  if (!Number.isInteger(quantity) || quantity <= 0) {
    throw new AppError(
      `Invalid quantity "${data.quantity ?? ""}" — must be a whole number greater than 0`,
      400
    );
  }

  const discount = Number(data.discount ?? 0);
  if (!Number.isFinite(discount) || discount < 0) {
    throw new AppError(
      `Invalid discount "${data.discount}" — must be a number 0 or greater (leave blank for none)`,
      400
    );
  }

  let amount;
  const amountIsBlank =
    data.amount === undefined || data.amount === null || data.amount === "";

  if (amountIsBlank) {
    const ticketType = await TicketType.findOne({
      _id: data.ticketTypeId,
      eventId: data.eventId,
      isDeleted: false,
    }).select("amount");

    if (!ticketType) {
      throw new AppError("Ticket Type not found for this event", 404);
    }

    amount = ticketType.amount * quantity - discount;
  } else {
    amount = Number(data.amount);
  }

  if (!Number.isFinite(amount) || amount < 0) {
    throw new AppError(
      `Invalid amount "${data.amount ?? ""}" — must be a number 0 or greater (or leave blank to use the ticket price)`,
      400
    );
  }

  return { ...data, quantity, discount, amount };
};

// ================= DUPLICATE BOOKING CHECK =================
// A "duplicate" here means: the SAME MOBILE NUMBER already has a
// non-deleted booking for the SAME event + SAME ticket type. The
// customer's name (and quantity / amount / remark) is deliberately NOT
// compared: the same NAME with a DIFFERENT mobile number is allowed,
// while the same mobile number is always flagged, whatever the name.
//
// The mobile number is compared in normalised form, so the SAME number
// typed differently is still caught:
//     9876543210  ==  919876543210  ==  +91 98765 43210
// Older bookings were saved exactly as typed (before normalisation
// existed), so every spelling they may have been stored under is
// matched (see getMobileNumberVariants).
//
// This catches:
//   1. The SAME CSV file being imported twice (accident / retry).
//   2. The SAME number appearing twice INSIDE one CSV — bulkImportBookings
//      below processes rows strictly one at a time (never Promise.all),
//      so the first row's booking is already committed by the time the
//      second row's check runs.
// isDeleted: false so a booking the admin has since deleted does NOT
// block re-importing that number.
const findDuplicateBooking = async (data) => {
  const { eventId, ticketTypeId, mobileNumber } = data;

  const mobileVariants = getMobileNumberVariants(mobileNumber);
  if (mobileVariants.length === 0) return null;

  return Booking.findOne({
    eventId,
    ticketTypeId,
    mobileNumber: { $in: mobileVariants },
    isDeleted: { $ne: true },
    // A CANCELLED booking is dead (its QR is void and the seats went back to
    // stock), so it must not block a new booking for the same number - e.g.
    // after "Cancel Pass" the guest can be approved again and get a fresh pass.
    bookingStatus: { $ne: "Cancelled" },
  })
    .select("bookingNumber name mobileNumber")
    .lean();
};

// ================= CSV ROW: NAME / MOBILE / EMAIL VALIDATION =================
// The CSV path never runs express-validator (that only guards the
// single-booking route), so the same basic checks are done here per row
// and reported as a normal row-level error — one bad row never stops the
// rest of the file.
const validateCsvContactFields = (data) => {
  const name = String(data.name ?? "").trim();
  if (!name) {
    throw new AppError("Name is required", 400);
  }

  const normalizedMobileNumber = normalizeMobileNumber(data.mobileNumber);
  if (!normalizedMobileNumber) {
    throw new AppError(
      `Invalid mobile number "${data.mobileNumber ?? ""}" — ${MOBILE_ERROR_MESSAGE}`,
      400
    );
  }

  const email = String(data.email ?? "").trim();
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    throw new AppError(`Invalid email "${email}"`, 400);
  }

  return { ...data, name, mobileNumber: normalizedMobileNumber, email };
};

// ================= CSV: PREPARE ROWS / SAME-MOBILE-IN-FILE CHECK =================
// One CSV row -> a ready-to-book data object (name / mobile / email
// checks, event + ticket resolution, quantity/amount/discount). Shared
// by the real import AND the pre-import check so both judge a row the
// same way. Never throws: a bad row comes back with `error` set.
const prepareCsvRows = async (rows) => {
  const prepared = [];

  // Sequential, on purpose (see the comment above bulkImportBookings).
  for (const { rowNumber, data: rawData } of rows) {
    try {
      // Name / mobile (with or without 91) / email checks — the CSV path
      // skips the route-level express-validator, so it's done here.
      const contactChecked = validateCsvContactFields(rawData);

      // Resolves eventName/ticketTypeName -> eventId/ticketTypeId when the
      // row didn't already provide the raw IDs.
      const resolved = await resolveEventAndTicketType(contactChecked);

      // Validates quantity/discount/amount and fills a blank amount from
      // the ticket price (see normalizeRowNumbers above).
      const data = await normalizeRowNumbers(resolved);

      prepared.push({ rowNumber, rawData, data });
    } catch (error) {
      prepared.push({
        rowNumber,
        rawData,
        error: error.message || "Failed to create booking",
      });
    }
  }

  return prepared;
};

// Groups the rows of ONE file that carry the SAME mobile number for the
// SAME event + ticket type — e.g. two rows of "9876543210, qty 2". Such
// rows must be merged into a single row (qty 4) or given different
// numbers BEFORE anything is booked, so they are reported back instead
// of silently booking the first row and skipping the rest.
const findSameMobileGroups = (prepared) => {
  const groups = new Map();

  for (const item of prepared) {
    if (!item.data) continue;

    const key = `${item.data.eventId}|${item.data.ticketTypeId}|${item.data.mobileNumber}`;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(item);
  }

  return [...groups.values()]
    .filter((items) => items.length > 1)
    .map((items) => ({
      mobileNumber: items[0].data.mobileNumber,
      rows: items.map((item) => ({
        row: item.rowNumber,
        name: item.data.name,
        quantity: Number(item.data.quantity) || 0,
      })),
      totalQuantity: items.reduce(
        (sum, item) => sum + (Number(item.data.quantity) || 0),
        0
      ),
    }));
};

const buildSameMobileMessage = (groups) =>
  `Same mobile number found in more than one row — ${groups
    .map(
      (g) =>
        `${g.mobileNumber} in rows ${g.rows.map((r) => r.row).join(", ")} (total qty ${g.totalQuantity})`
    )
    .join("; ")}. Merge them into ONE row (add the quantities) or change the mobile number, then import again. No bookings were created.`;

// ================= CHECK CSV BEFORE IMPORT (NOTHING IS CREATED) =================
// Powers the warning shown as soon as a file is chosen. Read-only: it
// creates no booking, deducts no ticket and sends no message.
const checkBookingCsv = async (fileBuffer) => {
  if (!fileBuffer || fileBuffer.length === 0) {
    throw new AppError("CSV file is required", 400);
  }

  const rows = await parseBookingCsvBuffer(fileBuffer);

  if (rows.length === 0) {
    throw new AppError("CSV file has no data rows", 400);
  }

  const prepared = await prepareCsvRows(rows);
  const sameMobileGroups = findSameMobileGroups(prepared);

  const rowErrors = [];
  const existingDuplicates = [];

  for (const item of prepared) {
    if (item.error) {
      rowErrors.push({
        row: item.rowNumber,
        name: item.rawData.name,
        mobileNumber: item.rawData.mobileNumber,
        error: item.error,
      });
      continue;
    }

    const existing = await findDuplicateBooking(item.data);
    if (existing) {
      existingDuplicates.push({
        row: item.rowNumber,
        name: item.data.name,
        mobileNumber: item.data.mobileNumber,
        existingBookingNumber: existing.bookingNumber,
        existingName: existing.name,
      });
    }
  }

  return {
    totalRows: prepared.length,
    // Import is only blocked by the same mobile number repeating INSIDE
    // the file; rows that already have a booking are simply skipped.
    canImport: sameMobileGroups.length === 0,
    sameMobileGroups,
    existingDuplicates,
    rowErrors,
  };
};

const bulkImportBookings = async (fileBuffer, createdBy) => {
  if (!fileBuffer || fileBuffer.length === 0) {
    throw new AppError("CSV file is required", 400);
  }

  const rows = await parseBookingCsvBuffer(fileBuffer);

  if (rows.length === 0) {
    throw new AppError("CSV file has no data rows", 400);
  }

  const prepared = await prepareCsvRows(rows);

  // Same mobile number in more than one row of this file: refuse the
  // WHOLE import up front (nothing is created) until the admin merges
  // those rows or changes a number. Enforced here as well as in the UI
  // so it cannot be bypassed.
  const sameMobileGroups = findSameMobileGroups(prepared);
  if (sameMobileGroups.length > 0) {
    throw new AppError(buildSameMobileMessage(sameMobileGroups), 409);
  }

  const results = [];

  // Sequential, on purpose — see the comment above this function for why
  // this is not parallelized with Promise.all.
  for (const { rowNumber, rawData, data, error: prepareError } of prepared) {
    if (prepareError) {
      results.push({
        row: rowNumber,
        success: false,
        name: rawData.name,
        mobileNumber: rawData.mobileNumber,
        error: prepareError,
      });
      continue;
    }

    try {
      const existing = await findDuplicateBooking(data);

      if (existing) {
        results.push({
          row: rowNumber,
          success: false,
          duplicate: true,
          name: rawData.name,
          mobileNumber: rawData.mobileNumber,
          existingBookingNumber: existing.bookingNumber,
          error: `Duplicate — this row has the same mobile number as booking ${existing.bookingNumber} (name: "${existing.name}") for the same event & ticket type. Skipped, no new booking or tickets were created.`,
        });
        continue;
      }

      const result = await createBooking(data, createdBy);

      results.push({
        row: rowNumber,
        success: true,
        bookingNumber: result.booking.bookingNumber,
        bookingId: result.booking._id,
        totalTickets: result.totalTickets,
      });
    } catch (error) {
      results.push({
        row: rowNumber,
        success: false,
        name: rawData.name,
        mobileNumber: rawData.mobileNumber,
        error: error.message || "Failed to create booking",
      });
    }
  }

  const successCount = results.filter((r) => r.success).length;
  const duplicateCount = results.filter((r) => r.duplicate).length;
  const failureCount = results.length - successCount;

  // Overall outcome, so the UI never has to guess:
  //   "success" — every row created a booking
  //   "partial" — some rows created, some duplicate/failed
  //   "failed"  — NOTHING was created (all duplicates and/or errors)
  const status =
    successCount === 0
      ? "failed"
      : failureCount === 0
      ? "success"
      : "partial";

  return {
    status,
    totalRows: results.length,
    successCount,
    duplicateCount,
    failureCount,
    results,
  };
};

// ================= RESOLVE EVENT SCOPE (MULTIPLE ACTIVE EVENTS) =================
// Shared by getAllBookings and exportBookings so the table and the export
// can never diverge on which events they cover.
//
// - eventId supplied: scope is exactly that one event, as long as it's a
//   real, non-deleted event — its own bookings must stay visible/
//   exportable for as long as the Event document exists, even after it
//   has expired (Step 5: expiring an event must never hide its existing
//   data — only an explicit manual delete may, and a manual delete
//   already hard-removes the Event document itself, along with its
//   Bookings/BookingTickets in the same transaction, so there is nothing
//   further to exclude here once that happens).
// - eventId omitted: scope is EVERY currently active (isActive: true),
//   non-deleted, non-expired event — not just the first one — so bookings
//   from Event A and Event B are both included when both are active.
//   Previously this used Event.findOne(...), which silently discarded
//   every active event but the earliest-starting one. This "no eventId"
//   overview must include EXPIRED events too — expiring an event must
//   never hide its historical bookings (only a manual delete may), so
//   the endDateTime >= now restriction that used to be here has been
//   removed. isActive is left untouched: it's a separate, manually
//   controlled admin flag unrelated to time-based expiry.
const resolveEventScope = async (eventId) => {
  if (eventId) {
    const event = await Event.findOne({
      _id: eventId,
      isDeleted: { $ne: true },
    }).select("_id title startDateTime endDateTime");

    return event ? { eventIds: [event._id], events: [event] } : { eventIds: [], events: [] };
  }

  const activeEvents = await Event.find({
    isActive: true,
    isDeleted: { $ne: true },
  })
    .sort({ startDateTime: 1 })
    .select("_id title startDateTime endDateTime");

  return {
    eventIds: activeEvents.map((event) => event._id),
    events: activeEvents,
  };
};

// ================= GET ALL BOOKINGS =================
const getAllBookings = async (query) => {
  const {
    eventId,
    page = 1,
    limit = 10,
    bookingId,
    mobileNumber,
    name,
    createdBy,
    status,
    fromDate,
    toDate,
    search,
    type,
  } = query;

  // ================= CONVERT PAGINATION VALUES =================
  const currentPage = Math.max(Number(page) || 1, 1);
  const pageLimit = Math.max(Number(limit) || 10, 1);

  // ================= RESOLVE EVENT(S) =================
  // A specific eventId → only that event. No eventId → every currently
  // active event, combined (see resolveEventScope above).
  const { eventIds, events } = await resolveEventScope(eventId);

  // ================= NO MATCHING EVENT(S) =================
  if (eventIds.length === 0) {
    return {
      events: [],
      rows: [],
      pagination: {
        page: currentPage,
        limit: pageLimit,
        total: 0,
        totalPages: 0,
      },
    };
  }

  // ================= BUILD FILTER =================
  const filter = {
    eventId: { $in: eventIds },
  };

  // ================= DELETED / SUCCESS STATUS =================
  if (status === "Deleted") {
    filter.isDeleted = true;
  } else {
    // Default + Success
    filter.isDeleted = false;
  }

  // ================= BOOKING ID FILTER =================
  if (bookingId?.trim()) {
    filter.bookingNumber = {
      $regex: bookingId.trim(),
      $options: "i",
    };
  }

  // ================= MOBILE NUMBER FILTER =================
  if (mobileNumber?.trim()) {
    // "+91 98765 43210" / "919876543210" -> "9876543210", which matches a
    // booking stored either way; also regex-safe (a raw "+" used to throw).
    filter.mobileNumber = {
      $regex: toMobileFilterDigits(mobileNumber),
      $options: "i",
    };
  }

  // ================= NAME FILTER =================
  if (name?.trim()) {
    filter.name = {
      $regex: name.trim(),
      $options: "i",
    };
  }

  // ================= CREATED BY FILTER =================
  if (createdBy) {
    filter.createdBy = createdBy;
  }

  // ================= GLOBAL SEARCH FILTER =================
  if (search?.trim()) {
    const searchValue = normalizeMobileSearchTerm(search.trim());

    filter.$or = [
      {
        bookingNumber: {
          $regex: searchValue,
          $options: "i",
        },
      },
      {
        name: {
          $regex: searchValue,
          $options: "i",
        },
      },
      {
        mobileNumber: {
          $regex: searchValue,
          $options: "i",
        },
      },
    ];
  }

  // ================= GUEST / CREW TAB =================
  // Passes sent from the Crew page are crew bookings (Booking.isCrew, or the
  // remark of older ones). type=crew lists only those, every other request
  // (default "guest") lists everything else - same split as the Entry Report.
  const crewBookingCondition = [
    { isCrew: true },
    { remark: { $regex: "^Pass sent from Crew", $options: "i" } },
  ];
  if (type === "crew") {
    filter.$and = [...(filter.$and || []), { $or: crewBookingCondition }];
  } else {
    filter.$nor = crewBookingCondition;
  }

  // ================= DATE FILTER =================
  if (fromDate || toDate) {
    filter.createdAt = {};

    if (fromDate) {
      const startDate = new Date(fromDate);

      if (!Number.isNaN(startDate.getTime())) {
        startDate.setHours(0, 0, 0, 0);
        filter.createdAt.$gte = startDate;
      }
    }

    if (toDate) {
      const endDate = new Date(toDate);

      if (!Number.isNaN(endDate.getTime())) {
        endDate.setHours(23, 59, 59, 999);
        filter.createdAt.$lte = endDate;
      }
    }

    // Remove empty createdAt filter
    if (Object.keys(filter.createdAt).length === 0) {
      delete filter.createdAt;
    }
  }

  // ================= TOTAL COUNT =================
  const total = await Booking.countDocuments(filter);

  // ================= TOTAL PAGES =================
  const totalPages = Math.ceil(total / pageLimit);

  // ================= PAGINATION OFFSET =================
  const skip = (currentPage - 1) * pageLimit;

  // ================= FETCH BOOKINGS =================
  const bookings = await Booking.find(filter)
    .populate(
      "eventId",
      "title startDateTime endDateTime"
    )
    .populate(
      "ticketTypeId",
      "ticketName amount"
    )
    .populate(
      "createdBy",
      "name"
    )
    .sort({
      createdAt: -1,
    })
    .skip(skip)
    .limit(pageLimit)
    .lean();

  // ================= RESPONSE =================
  return {
    events,
    rows: bookings,
    pagination: {
      page: currentPage,
      limit: pageLimit,
      total,
      totalPages,
    },
  };
};
// ================= DELETE BOOKING =================
const deleteBooking = async (bookingId, remark, deletedBy) => {
  if (!remark || !remark.trim()) {
    throw new AppError("Delete remark is required", 400);
  }

  const booking = await Booking.findById(bookingId);

  if (!booking) {
    throw new AppError("Booking not found", 404);
  }

  if (booking.isDeleted) {
    throw new AppError("Booking already deleted", 400);
  }

  booking.isDeleted = true;
  booking.deleteRemark = remark.trim();
  booking.deletedAt = new Date();
  booking.deletedBy = deletedBy;

  await booking.save();

  // Keep Guest List in sync: clear "Pass sent" on the contact that owned it.
  try {
    const Contact = require("../models/contact.model");
    await Contact.updateMany(
      { passBookingId: booking._id },
      { $set: { passSentAt: null, passEventId: null, passBookingId: null } }
    );
  } catch (e) {
    console.error("Failed to clear contact pass mark:", e.message);
  }

  return booking;
};
// ================= EXPORT ALL BOOKINGS =================
const exportBookings = async (query, res) => {
  const {
    eventId,
    bookingId,
    mobileNumber,
    name,
    createdBy,
    status,
    fromDate,
    toDate,
    search,
    type,
  } = query;

  // ================= RESOLVE EVENT(S) =================
  // Same resolution as getAllBookings (see resolveEventScope above), so
  // the exported file always matches what the table is showing: a
  // specific eventId if supplied, otherwise every currently active event
  // combined — never just the single earliest one.
  const { eventIds } = await resolveEventScope(eventId);

  if (eventIds.length === 0) {
    throw new AppError("No active event found.", 404);
  }

  // ================= BUILD FILTER =================
  const filter = {
    eventId: { $in: eventIds },
  };

  // ================= DELETED / SUCCESS STATUS =================
  if (status === "Deleted") {
    filter.isDeleted = true;
  } else {
    // Default + Success
    filter.isDeleted = false;
  }

  // ================= BOOKING ID FILTER =================
  if (bookingId?.trim()) {
    filter.bookingNumber = {
      $regex: bookingId.trim(),
      $options: "i",
    };
  }

  // ================= MOBILE NUMBER FILTER =================
  if (mobileNumber?.trim()) {
    // "+91 98765 43210" / "919876543210" -> "9876543210", which matches a
    // booking stored either way; also regex-safe (a raw "+" used to throw).
    filter.mobileNumber = {
      $regex: toMobileFilterDigits(mobileNumber),
      $options: "i",
    };
  }

  // ================= NAME FILTER =================
  if (name?.trim()) {
    filter.name = {
      $regex: name.trim(),
      $options: "i",
    };
  }

  // ================= CREATED BY FILTER =================
  if (createdBy) {
    filter.createdBy = createdBy;
  }

  // ================= GLOBAL SEARCH FILTER =================
  if (search?.trim()) {
    const searchValue = normalizeMobileSearchTerm(search.trim());

    filter.$or = [
      {
        bookingNumber: {
          $regex: searchValue,
          $options: "i",
        },
      },
      {
        name: {
          $regex: searchValue,
          $options: "i",
        },
      },
      {
        mobileNumber: {
          $regex: searchValue,
          $options: "i",
        },
      },
    ];
  }

  // ================= GUEST / CREW TAB =================
  // Passes sent from the Crew page are crew bookings (Booking.isCrew, or the
  // remark of older ones). type=crew lists only those, every other request
  // (default "guest") lists everything else - same split as the Entry Report.
  const crewBookingCondition = [
    { isCrew: true },
    { remark: { $regex: "^Pass sent from Crew", $options: "i" } },
  ];
  if (type === "crew") {
    filter.$and = [...(filter.$and || []), { $or: crewBookingCondition }];
  } else {
    filter.$nor = crewBookingCondition;
  }

  // ================= DATE FILTER =================
  if (fromDate || toDate) {
    filter.createdAt = {};

    if (fromDate) {
      const startDate = new Date(fromDate);

      if (!Number.isNaN(startDate.getTime())) {
        startDate.setHours(0, 0, 0, 0);
        filter.createdAt.$gte = startDate;
      }
    }

    if (toDate) {
      const endDate = new Date(toDate);

      if (!Number.isNaN(endDate.getTime())) {
        endDate.setHours(23, 59, 59, 999);
        filter.createdAt.$lte = endDate;
      }
    }

    // Remove empty createdAt filter
    if (Object.keys(filter.createdAt).length === 0) {
      delete filter.createdAt;
    }
  }

  // ================= FETCH ALL BOOKINGS =================
  const bookings = await Booking.find(filter)
    .populate(
      "eventId",
      "title startDateTime endDateTime"
    )
    .populate(
      "ticketTypeId",
      "ticketName amount"
    )
    .populate(
      "createdBy",
      "name"
    )
    .sort({
      createdAt: -1,
    })
    .lean();

  // ================= REGISTERED ATTENDEE DETAILS (PER TICKET) =================
  // Registration completion is tracked solely via BookingTicket.isRegistered
  // (set true in publicRegistration.service.js once the attendee submits the
  // public registration form). This is intentionally independent of QR/scan
  // status (BookingTicket.status/scannedAt) — a ticket can be "Active" and
  // never scanned yet still have a completed registration, and that
  // registration data must still be exported. Fetched in a single batched
  // query (rather than per-booking) to avoid N+1 lookups, then grouped by
  // bookingId below so each booking's registered attendees can be looked up
  // in-memory while building rows.
  const bookingIds = bookings.map((item) => item._id);

  const registeredTickets = await BookingTicket.find({
    bookingId: { $in: bookingIds },
    isRegistered: true,
  })
    .select("bookingId ticketNumber attendee")
    .sort({ "attendee.registeredAt": 1 })
    .lean();

  const registeredTicketsByBooking = registeredTickets.reduce(
    (acc, ticket) => {
      const key = String(ticket.bookingId);

      if (!acc[key]) {
        acc[key] = [];
      }

      acc[key].push(ticket);

      return acc;
    },
    {}
  );

  // ================= WORKBOOK =================
  const ExcelJS = require("exceljs");

  const workbook = new ExcelJS.Workbook();

  workbook.creator = "Event Management CRM";
  workbook.created = new Date();

  const worksheet = workbook.addWorksheet("Booking Report");

  worksheet.columns = [
    // Only completed registrations are exported (see row-building loop
    // below), identified by Event + Ticket Type, with the registered
    // attendee's own details from BookingTicket.attendee.
    {
      header: "Event",
      key: "event",
      width: 25,
    },
    {
      header: "Ticket Type",
      key: "ticketType",
      width: 22,
    },
    {
      header: "Ticket Number",
      key: "ticketNumber",
      width: 22,
    },
    {
      header: "Attendee Name",
      key: "attendeeName",
      width: 25,
    },
    {
      header: "Attendee Mobile",
      key: "attendeeMobile",
      width: 18,
    },
    {
      header: "Attendee Email",
      key: "attendeeEmail",
      width: 30,
    },
    {
      header: "Registered At",
      key: "registeredAt",
      width: 22,
    },
  ];

  // ================= HEADER STYLE =================
  worksheet.getRow(1).font = {
    bold: true,
    color: {
      argb: "FFFFFFFF",
    },
  };

  worksheet.getRow(1).fill = {
    type: "pattern",
    pattern: "solid",
    fgColor: {
      argb: "1F4E78",
    },
  };

  worksheet.getRow(1).alignment = {
    vertical: "middle",
    horizontal: "center",
  };

  // ================= ROWS =================
  bookings.forEach((item) => {
    // Only Event + Ticket Type are needed to identify the row — no other
    // booking-level fields (booker name/mobile/email, quantity, amount,
    // discount, createdBy, remark, createdAt, status) are exported.
    const baseRow = {
      event: item.eventId?.title || "-",

      ticketType: item.ticketTypeId?.ticketName || "-",
    };

    const registeredForBooking =
      registeredTicketsByBooking[String(item._id)] || [];

    if (registeredForBooking.length === 0) {
      // No BookingTicket for this booking has completed registration yet —
      // skip it entirely, since only completed registrations should appear
      // in the export.
      return;
    }

    // Quantity > 1: add one row per successfully registered attendee,
    // repeating Event + Ticket Type on each.
    registeredForBooking.forEach((ticket) => {
      worksheet.addRow({
        ...baseRow,
        ticketNumber: ticket.ticketNumber || "-",
        attendeeName: ticket.attendee?.name || "-",
        attendeeMobile: ticket.attendee?.mobileNumber || "-",
        attendeeEmail: ticket.attendee?.email || "-",
        registeredAt: ticket.attendee?.registeredAt
          ? new Date(ticket.attendee.registeredAt).toLocaleString("en-GB")
          : "-",
      });
    });
  });

  // ================= DOWNLOAD =================
  res.setHeader(
    "Content-Type",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
  );

  res.setHeader(
    "Content-Disposition",
    `attachment; filename=BookingReport_${Date.now()}.xlsx`
  );

  await workbook.xlsx.write(res);

  res.end();
};
// get booking by id
// ================= GET BOOKING BY ID =================
const getBookingById = async (bookingId) => {
  const booking = await Booking.findById(bookingId)
    .populate(
      "eventId",
      "title startDateTime endDateTime venueName image address"
    )
    .populate(
      "ticketTypeId",
      "ticketName amount"
    )
    .populate(
      "createdBy",
      "name email"
    );

  if (!booking) {
    throw new AppError("Booking not found", 404);
  }

  const tickets = await BookingTicket.find({
    bookingId: booking._id,
  })
    .select("-qrToken -qrImagePublicId -registrationToken -__v")
    .sort({ createdAt: 1 });

  return {
    ...booking.toObject(),
    tickets,
  };
};

// ================= EDIT BOOKING (ALL FIELDS) =================
// PUT /api/bookings/update/:id
//
// Editable: name, mobile, email, company/brand, remark, discount, and
// (for single-QR bookings) quantity + ticket type.
// NOT editable: event, bookingNumber, invitationId (the pass link never
// changes, so a link already sent on WhatsApp keeps working and the pass
// page simply shows the new details).
//
// Rules
//  - A booking that has already been scanned (any ticket "Used") is locked.
//  - Quantity / ticket type can be changed only for single_qr bookings
//    (new flow). Old per-ticket bookings have per-guest registrations, so
//    only their contact fields are editable.
//  - Stock (TicketType.availableCount) and amount are recalculated here.
//  - Quantity up   -> extra tickets are created (same QR/ticket generation
//                     as createBooking). Quantity down -> newest tickets
//                     are cancelled. The first ticket (the one whose QR was
//                     sent) is never removed.
//  - `resendInvitation: true` re-sends the WhatsApp invitation (same link)
//    after the edit is saved; a failed send never undoes the edit.
const updateBooking = async (bookingId, data = {}) => {
  const session = await mongoose.startSession();
  let committed = false;

  try {
    session.startTransaction();

    const booking = await Booking.findOne({
      _id: bookingId,
      isDeleted: { $ne: true },
    }).session(session);

    if (!booking) {
      throw new AppError("Booking not found", 404);
    }

    const event = await Event.findById(booking.eventId).session(session);
    if (!event) {
      throw new AppError("Event not found", 404);
    }
    if (new Date(event.endDateTime) < new Date()) {
      throw new AppError("This event has already ended, so the booking cannot be edited.", 400);
    }

    const tickets = await BookingTicket.find({ bookingId: booking._id })
      .sort({ createdAt: 1, _id: 1 })
      .session(session);

    if (tickets.some((t) => t.status === "Used")) {
      throw new AppError(
        "This booking has already been checked in at the gate, so it can no longer be edited.",
        400
      );
    }

    const isSingleQr = booking.entryMode === "single_qr";

    // ----- contact fields -----
    const name = data.name !== undefined ? String(data.name).trim() : booking.name;
    if (!name) {
      throw new AppError("Name is required", 400);
    }

    const mobileNumber =
      data.mobileNumber !== undefined
        ? normalizeMobileNumber(data.mobileNumber)
        : booking.mobileNumber;
    if (!mobileNumber) {
      throw new AppError(MOBILE_ERROR_MESSAGE, 400);
    }

    const email = data.email !== undefined ? String(data.email || "").trim() : booking.email;
    const companyName =
      data.companyName !== undefined ? String(data.companyName || "").trim() : booking.companyName;
    const remark = data.remark !== undefined ? String(data.remark || "").trim() : booking.remark;
    const discount = data.discount !== undefined ? Number(data.discount || 0) : booking.discount;

    if (Number.isNaN(discount) || discount < 0) {
      throw new AppError("Invalid discount", 400);
    }

    // ----- quantity / ticket type -----
    const newQuantity =
      data.quantity !== undefined && data.quantity !== ""
        ? Number(data.quantity)
        : booking.quantity;
    const newTicketTypeId = data.ticketTypeId || String(booking.ticketTypeId);

    if (!Number.isInteger(newQuantity) || newQuantity < 1) {
      throw new AppError("Invalid booking quantity", 400);
    }

    const typeChanged = String(newTicketTypeId) !== String(booking.ticketTypeId);
    const quantityChanged = newQuantity !== booking.quantity;

    if ((typeChanged || quantityChanged) && !isSingleQr) {
      throw new AppError(
        "Quantity and ticket type can only be changed for bookings created with the single QR invitation. Other details can still be edited.",
        400
      );
    }

    // ----- duplicate mobile check (same rule as create) -----
    const mobileChanged = mobileNumber !== booking.mobileNumber;
    const allowDuplicate = data.allowDuplicate === true || data.allowDuplicate === "true";

    if ((mobileChanged || typeChanged) && !allowDuplicate) {
      const variants = getMobileNumberVariants(mobileNumber);
      const duplicate = variants.length
        ? await Booking.findOne({
            _id: { $ne: booking._id },
            eventId: booking.eventId,
            ticketTypeId: newTicketTypeId,
            mobileNumber: { $in: variants },
            isDeleted: { $ne: true },
            bookingStatus: { $ne: "Cancelled" },
          })
            .select("bookingNumber name mobileNumber")
            .lean()
            .session(session)
        : null;

      if (duplicate) {
        throw new AppError(
          `Duplicate booking — this mobile number (${data.mobileNumber ?? mobileNumber}) already has booking ${duplicate.bookingNumber} (under the name "${duplicate.name}") for this event & ticket type. No changes were saved.`,
          409
        );
      }
    }

    // ----- stock (availableCount) -----
    let ticketType;

    if (!typeChanged) {
      const delta = newQuantity - booking.quantity;

      if (delta > 0) {
        ticketType = await TicketType.findOneAndUpdate(
          { _id: booking.ticketTypeId, availableCount: { $gte: delta } },
          { $inc: { availableCount: -delta } },
          { new: true, session }
        );
        if (!ticketType) {
          throw new AppError("Ticket not available for the requested quantity", 400);
        }
      } else if (delta < 0) {
        ticketType = await TicketType.findOneAndUpdate(
          { _id: booking.ticketTypeId },
          { $inc: { availableCount: -delta } },
          { new: true, session }
        );
      } else {
        ticketType = await TicketType.findById(booking.ticketTypeId).session(session);
      }
    } else {
      // give the old ticket type its seats back, take them from the new one
      await TicketType.updateOne(
        { _id: booking.ticketTypeId },
        { $inc: { availableCount: booking.quantity } },
        { session }
      );

      ticketType = await TicketType.findOneAndUpdate(
        {
          _id: newTicketTypeId,
          eventId: booking.eventId,
          isDeleted: false,
          availableCount: { $gte: newQuantity },
        },
        { $inc: { availableCount: -newQuantity } },
        { new: true, session }
      );
      if (!ticketType) {
        throw new AppError("Ticket not available", 400);
      }
    }

    if (!ticketType) {
      throw new AppError("Ticket type not found", 404);
    }

    // ----- amount = rate x quantity - discount (always recalculated here) -----
    const gross = ticketType.amount * newQuantity;
    if (discount > gross) {
      throw new AppError("Discount cannot exceed the amount", 400);
    }
    const amount = gross - discount;

    // ----- tickets (single QR bookings only) -----
    if (isSingleQr && (typeChanged || quantityChanged)) {
      const passDate =
        Array.isArray(ticketType.allowDates) && ticketType.allowDates.length > 0
          ? ticketType.allowDates[0]
          : null;

      const live = tickets.filter((t) => t.status !== "Cancelled");

      if (newQuantity > live.length) {
        const eventCode = await eventService.getOrCreateEventCode(event, session);
        const extra = [];

        for (let i = 0; i < newQuantity - live.length; i++) {
          const ticketNumber = await generateTicketNumber(event._id, eventCode, session);
          const qrToken = generateQrToken({ ticketNumber });
          const qrBuffer = await generateQrCode(qrToken);
          const qrUpload = await uploadImage(qrBuffer, "event-management/qr-codes", "image", {
            format: "png",
          });
          const ticketId = new mongoose.Types.ObjectId();

          extra.push({
            _id: ticketId,
            bookingId: booking._id,
            eventId: booking.eventId,
            ticketTypeId: newTicketTypeId,
            bookingNumber: booking.bookingNumber,
            ticketNumber,
            qrToken,
            qrImage: qrUpload.url,
            qrImagePublicId: qrUpload.public_id,
            status: "Active",
            passDate,
            registrationToken: generateRegistrationToken(ticketId),
          });
        }

        await BookingTicket.insertMany(extra, { session });
      } else if (newQuantity < live.length) {
        // never touch the first ticket: its QR is the one on the WhatsApp pass
        const toCancel = live.slice(newQuantity).map((t) => t._id);
        await BookingTicket.updateMany(
          { _id: { $in: toCancel } },
          { $set: { status: "Cancelled" } },
          { session }
        );
      }

      if (typeChanged) {
        await BookingTicket.updateMany(
          { bookingId: booking._id },
          { $set: { ticketTypeId: newTicketTypeId, passDate } },
          { session }
        );
      }
    }

    // ----- save booking -----
    booking.name = name;
    booking.mobileNumber = mobileNumber;
    booking.email = email;
    booking.companyName = companyName;
    booking.remark = remark;
    booking.discount = discount;
    booking.quantity = newQuantity;
    booking.ticketTypeId = newTicketTypeId;
    booking.amount = amount;
    await booking.save({ session });

    await session.commitTransaction();
    committed = true;

    // ----- optional WhatsApp resend (never undoes the edit) -----
    let whatsappSent = false;
    let whatsappError = null;
    const wantsResend = data.resendInvitation === true || data.resendInvitation === "true";

    if (wantsResend && isSingleQr) {
      try {
        await invitationService.sendInvitationMessage({ booking, event });
        whatsappSent = true;
      } catch (error) {
        whatsappError = error.message || "WhatsApp send failed";
        console.error(`WhatsApp resend after edit failed for ${booking.bookingNumber}:`, error);
      }
    }

    const liveTickets = await BookingTicket.countDocuments({
      bookingId: booking._id,
      status: { $ne: "Cancelled" },
    });

    return { booking, totalTickets: liveTickets, whatsappSent, whatsappError };
  } catch (error) {
    if (!committed && session.inTransaction()) {
      await session.abortTransaction();
    }
    throw error;
  } finally {
    await session.endSession();
  }
};

module.exports = {
  createBooking,
  updateBooking,
  bulkImportBookings,
  checkBookingCsv,
  getAllBookings,
  deleteBooking,
  getBookingById,
  exportBookings
};