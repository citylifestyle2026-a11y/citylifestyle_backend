const Event = require("../models/event.model.js");
const Booking = require("../models/booking.model.js");
const BookingTicket = require("../models/bookingTicket.model.js");
const TicketType = require("../models/ticketType.model.js");
const Crew = require("../models/crew.model.js");
const { getRsvpSummary } = require("./rsvp.service");

// Passes sent from the Crew page are crew bookings (Booking.isCrew = true;
// older ones are recognised by their remark). They are shown in their own
// "Crew" section on the dashboard and must never be mixed into the guest
// numbers (Booking / Entry Report / Attendance).
const CREW_REMARK_RX = /^Pass sent from Crew/i;
const GUEST_ONLY = {
    isCrew: { $ne: true },
    remark: { $not: CREW_REMARK_RX },
};
const CREW_ONLY = {
    $or: [{ isCrew: true }, { remark: CREW_REMARK_RX }],
};

// Get Active Event
// An event is "currently running" while isActive === true AND its
// endDateTime has not yet passed — that part is unchanged. But an event
// expiring must never hide its own historical data (Step 5): if nothing
// is currently running, this now falls back to the most recently expired
// (but not yet deleted) event instead of returning null, so the
// Dashboard keeps showing that event's booking/pass counts until an
// Admin explicitly deletes it. A deleted event's document no longer
// exists at all (hard delete, cascading to its Bookings/BookingTickets
// in the same transaction — see event.service.js), so nothing further
// needs excluding here once that happens. isActive stays a manually
// controlled flag (never written here or auto-flipped by expiry).
const getActiveEvent = async () => {
    const now = new Date();

    const runningEvent = await Event.findOne({
        isActive: true,
        endDateTime: { $gte: now },
    })
        .sort({ startDateTime: 1 })
        .lean();

    if (runningEvent) {
        return runningEvent;
    }

    const lastExpiredEvent = await Event.findOne({
        isActive: true,
        endDateTime: { $lt: now },
    })
        .sort({ endDateTime: -1 })
        .lean();

    return lastExpiredEvent;
};


// Today Booking
const getTodayBooking = async (eventId) => {
    const start = new Date();
    start.setHours(0, 0, 0, 0);

    const end = new Date();
    end.setHours(23, 59, 59, 999);

    // Deleted (soft-deleted) bookings must not count — same rule as
    // getTotalBooking / getPassBookingBreakdown below.
    // Cancelled bookings (e.g. a cancelled pass) are not counted either.
    return await Booking.countDocuments({
        eventId,
        ...GUEST_ONLY,
        isDeleted: false,
        bookingStatus: { $ne: "Cancelled" },
        createdAt: {
            $gte: start,
            $lte: end,
        },
    });
};


// Total Booking
// "Total Booking" is the total number of TICKETS booked (sum of each
// Booking's quantity), not the number of Booking documents — e.g. 2
// Booking records with quantity 2 each must read as 4, not 2.
const getTotalBooking = async (eventId) => {
    const result = await Booking.aggregate([
        // A cancelled booking (e.g. a cancelled pass) is not a booking any more.
        { $match: { eventId, ...GUEST_ONLY, isDeleted: false, bookingStatus: { $ne: "Cancelled" } } },
        { $group: { _id: null, qty: { $sum: "$quantity" } } },
    ]);

    return result[0]?.qty || 0;
};


// ================= PASS BOOKING (Today + Total, shared) =================
// Ticket-Type-wise booked quantity + amount, optionally restricted to a
// createdAt date range. Used by both getTodayPassBooking (range = today)
// and getTotalPassBooking (range = undefined = all time), so the exact
// same correct logic backs both cards instead of duplicating it.
//
// Booking.quantity (grouped by ticketTypeId) is the correct "booked"
// source — BookingTicket.status === "Used" measures scanned/entered
// attendees, a different metric, and was the original bug in both cards.
// TicketType.amount is the correct per-unit price (not Booking.amount),
// per the task's explicit formula: TicketType.amount x quantity.
//
// Only 2 queries total regardless of data volume: one $group/$sum
// aggregation on Booking, then one TicketType.find by the resulting
// ticketTypeIds — no N+1, and the summing happens in MongoDB, not by
// pulling every Booking into Node to loop over.
const getPassBookingBreakdown = async (eventId, dateRange) => {
    const match = {
        eventId,
        ...GUEST_ONLY,
        isDeleted: false,
        bookingStatus: "Confirmed",
    };

    if (dateRange) {
        match.createdAt = {
            $gte: dateRange.start,
            $lte: dateRange.end,
        };
    }

    const grouped = await Booking.aggregate([
        { $match: match },
        {
            $group: {
                _id: "$ticketTypeId",
                qty: { $sum: "$quantity" },
            },
        },
    ]);

    if (!grouped.length) {
        return {
            passBookingCounts: [],
            totalQty: 0,
            totalAmount: 0,
        };
    }

    const ticketTypeIds = grouped.map((g) => g._id);

    // Using the actual TicketType model (rather than a $lookup with a
    // hand-written collection name) so the correct collection is always
    // resolved by Mongoose itself.
    const ticketTypes = await TicketType.find(
        { _id: { $in: ticketTypeIds } },
        { ticketName: 1, amount: 1 }
    ).lean();

    const ticketTypeMap = new Map(
        ticketTypes.map((t) => [String(t._id), t])
    );

    const passBookingCounts = grouped
        .map((g) => {
            const ticketType = ticketTypeMap.get(String(g._id));
            const unitAmount = ticketType?.amount || 0;

            return {
                ticketTypeId: g._id,
                ticketName: ticketType?.ticketName || "Unknown Ticket Type",
                qty: g.qty,
                amount: unitAmount * g.qty,
            };
        })
        .sort((a, b) => a.ticketName.localeCompare(b.ticketName));

    const totalQty = passBookingCounts.reduce((sum, r) => sum + r.qty, 0);
    const totalAmount = passBookingCounts.reduce(
        (sum, r) => sum + r.amount,
        0
    );

    return { passBookingCounts, totalQty, totalAmount };
};

// Today Pass Booking — same breakdown, restricted to bookings created today.
const getTodayPassBooking = async (eventId) => {
    const start = new Date();
    start.setHours(0, 0, 0, 0);

    const end = new Date();
    end.setHours(23, 59, 59, 999);

    return getPassBookingBreakdown(eventId, { start, end });
};

// Total Pass Booking — same breakdown, all time (no date range).
const getTotalPassBooking = async (eventId) => {
    return getPassBookingBreakdown(eventId);
};


// Booking Chart Count
const getBookingCounts = async (eventId) => {

    const data = await Booking.aggregate([
        {
            $match: {
                eventId,
                ...GUEST_ONLY,
                // Deleted / cancelled bookings must not appear in the booking chart.
                isDeleted: false,
                bookingStatus: { $ne: "Cancelled" },
            },
        },
        {
            $group: {
                _id: {
                    $dateToString: {
                        format: "%Y-%m-%d",
                        date: "$createdAt",
                    },
                },
                count: {
                    $sum: 1,
                },
            },
        },
        {
            $sort: {
                _id: 1,
            },
        },
    ]);

    return data.map((item) => ({
        date: item._id,
        count: item.count,
    }));
};

// ================= QUANTITY-WISE BOOKINGS =================
// "1 qty ni ketli booking, 2 qty ni ketli booking ..." - bookings grouped by
// their own quantity value. Nothing is hard-coded: whatever quantities exist
// in the data are returned, so the moment someone makes a booking with a new
// quantity (e.g. 7) it shows up here (and on the dashboard) automatically.
//   quantity : the qty value of the booking (1, 2, 3 ...)
//   bookings : how many bookings were made with exactly that qty
//   tickets  : bookings x quantity (total tickets in those bookings)
// Same rules as the other guest numbers: crew, deleted and cancelled
// bookings are left out.
const getQuantityWiseBookings = async (eventId) => {
    const grouped = await Booking.aggregate([
        {
            $match: {
                eventId,
                ...GUEST_ONLY,
                isDeleted: false,
                bookingStatus: { $ne: "Cancelled" },
            },
        },
        {
            $group: {
                _id: "$quantity",
                bookings: { $sum: 1 },
            },
        },
        { $sort: { _id: 1 } },
    ]);

    return grouped.map((g) => ({
        quantity: g._id,
        bookings: g.bookings,
        tickets: g._id * g.bookings,
    }));
};

// Total Booking Details (Day Wise)
const getTotalBookingDetails = async (eventId) => {
    const bookings = await Booking.find({
        eventId,
        ...GUEST_ONLY,
        isDeleted: false,
        bookingStatus: { $ne: "Cancelled" },
    })
        .select("quantity ticketTypeId")
        .populate({
            path: "ticketTypeId",
            select: "allowDates",
        })
        .lean();

    const dateWiseMap = {};

    bookings.forEach((booking) => {
        if (!booking.ticketTypeId?.allowDates?.length) return;

        booking.ticketTypeId.allowDates.forEach((date) => {
            const key = new Date(date).toISOString().split("T")[0];

            if (!dateWiseMap[key]) {
                dateWiseMap[key] = {
                    date: key,
                    count: 0,
                };
            }

            dateWiseMap[key].count += booking.quantity;
        });
    });

    return Object.values(dateWiseMap).sort(
        (a, b) => new Date(a.date) - new Date(b.date)
    );
};
// ================= DASHBOARD COUNTS (SCOPED TO ONE EVENT) =================
// Backs the 5 standalone stat cards (Total Bookings, Registered Tickets,
// Pending Registrations, Scanned Entries, Registered but Not Scanned). Deliberately scoped to the
// SINGLE event resolved by the caller (whichever one is currently shown
// on the dashboard) rather than summed across every event in the system —
// mixing two different events' numbers into one total is misleading, not
// a feature. An event's own counts stay fully available for as long as
// the Event document exists (active or expired) — only an explicit manual
// delete removes it (and its Bookings/BookingTickets in the same
// transaction), so nothing further needs excluding here once that
// happens. "Total Bookings" is the total number of TICKETS (sum of
// Booking.quantity), matching getTotalBooking above — e.g. 2 Booking
// records with quantity 2 each read as 4, not 2.
const getDashboardCounts = async (eventId) => {
    if (!eventId) {
        return {
            totalBookings: 0,
            registeredTickets: 0,
            pendingRegistrations: 0,
            scannedEntries: 0,
            registeredNotScanned: 0,
            rsvp: { reminderSent: 0, yes: 0, no: 0, noResponse: 0 },
        };
    }

    // Deleting a booking is a soft delete (Booking.isDeleted = true) and
    // its BookingTickets are left in place, still with isRegistered:
    // false. Counting tickets by eventId alone therefore kept a deleted
    // booking's tickets in "Pending Registrations" (and, if they had been
    // registered, in "Registered Tickets") forever, even though "Total
    // Bookings" already excluded that booking. Tickets that belong to a
    // deleted booking are excluded from those two counts here. Works for
    // bookings deleted before this fix too, since it reads the current
    // Booking.isDeleted flag rather than anything stored on the ticket.
    const deletedBookingIds = await Booking.distinct("_id", {
        eventId,
        isDeleted: true,
    });

    // A CANCELLED booking (e.g. a cancelled pass) is no longer a real booking:
    // its tickets must not count as pending / registered / "not checked in".
    const cancelledBookingIds = await Booking.distinct("_id", {
        eventId,
        isDeleted: { $ne: true },
        bookingStatus: "Cancelled",
    });

    // Crew bookings have their own section (getCrewCounts) - keep them out of guest numbers.
    const crewBookingIds = await Booking.distinct("_id", { eventId, ...CREW_ONLY });

    const inactiveBookingIds = [...deletedBookingIds, ...cancelledBookingIds, ...crewBookingIds];

    const liveBookingTicketScope = {
        eventId,
        ...(inactiveBookingIds.length > 0
            ? { bookingId: { $nin: inactiveBookingIds } }
            : {}),
    };

    // Checked In: only the guests that really entered, and - like the Entry
    // Report - never the ones of a deleted booking.
    const checkedInScope = {
        eventId,
        status: "Used",
        ...(deletedBookingIds.length > 0 || crewBookingIds.length > 0
            ? { bookingId: { $nin: [...deletedBookingIds, ...crewBookingIds] } }
            : {}),
    };

    // Tickets of a single-QR PASS (WhatsApp invitation sent from Contact List
    // / Booking) are never "registered" one by one, so on their own they
    // would never show up as "not scanned". A pass that was sent and not
    // cancelled counts the same as a registration here.
    const passBookingIds = await Booking.distinct("_id", {
        eventId,
        ...GUEST_ONLY,
        isDeleted: { $ne: true },
        entryMode: "single_qr",
        bookingStatus: { $ne: "Cancelled" },
    });

    const [
        totalBookingsAgg,
        registeredTickets,
        pendingRegistrations,
        scannedEntries,
        registeredNotScanned,
    ] =
        await Promise.all([
            Booking.aggregate([
                { $match: { eventId, ...GUEST_ONLY, isDeleted: false, bookingStatus: { $ne: "Cancelled" } } },
                { $group: { _id: null, qty: { $sum: "$quantity" } } },
            ]),
            BookingTicket.countDocuments({
                ...liveBookingTicketScope,
                isRegistered: true,
                status: { $ne: "Cancelled" },
            }),
            BookingTicket.countDocuments({
                ...liveBookingTicketScope,
                isRegistered: false,
                status: { $ne: "Cancelled" },
            }),
            // Scanned Entries = guests checked in (same bookings as the
            // Entry Report, which leaves out deleted bookings).
            BookingTicket.countDocuments(checkedInScope),
            // Registered but Not Scanned: the attendee registered (so a
            // QR pass exists) yet the pass was never scanned at entry —
            // i.e. the person did not come to the event. Counted
            // directly on the tickets rather than as
            // (registeredTickets - scannedEntries), because Scanned
            // Entries is intentionally not narrowed to live/registered
            // tickets and a subtraction could therefore drift or even
            // go negative. Same live-booking scope as Registered
            // Tickets; a Cancelled ticket is not a no-show, so it is
            // left out along with the already-Used ones.
            BookingTicket.countDocuments({
                ...liveBookingTicketScope,
                $or: [
                    { isRegistered: true },
                    { bookingId: { $in: passBookingIds } },
                ],
                status: { $nin: ["Used", "Cancelled"] },
            }),
        ]);

    return {
        totalBookings: totalBookingsAgg[0]?.qty || 0,
        registeredTickets,
        pendingRegistrations,
        scannedEntries,
        registeredNotScanned,
    };
};

// ================= CREW COUNTS =================
// Own section on the dashboard. Crew members are people (not guests):
//  - totals by approval status come from the Crew collection (all events)
//  - pass / check-in numbers are scoped to the selected event
// A crew member saved before approval existed has no approvalStatus -> approved.
const getCrewCounts = async (eventId) => {
    const live = { isDeleted: { $ne: true } };

    const [total, pending, rejected, approvedExplicit, approvedLegacy] = await Promise.all([
        Crew.countDocuments(live),
        Crew.countDocuments({ ...live, approvalStatus: "pending" }),
        Crew.countDocuments({ ...live, approvalStatus: "rejected" }),
        Crew.countDocuments({ ...live, approvalStatus: "approved" }),
        Crew.countDocuments({ ...live, approvalStatus: { $exists: false } }),
    ]);

    const counts = {
        total,
        approved: approvedExplicit + approvedLegacy,
        pending,
        rejected,
        passSent: 0,
        checkedIn: 0,
        notCheckedIn: 0,
    };
    if (!eventId) return counts;

    const crewBookingIds = await Booking.distinct("_id", {
        eventId,
        isDeleted: { $ne: true },
        bookingStatus: { $ne: "Cancelled" },
        ...CREW_ONLY,
    });

    const [passSent, checkedIn, notCheckedIn] = await Promise.all([
        Crew.countDocuments({ ...live, passSentAt: { $ne: null }, passEventId: eventId }),
        BookingTicket.countDocuments({ eventId, bookingId: { $in: crewBookingIds }, status: "Used" }),
        BookingTicket.countDocuments({
            eventId,
            bookingId: { $in: crewBookingIds },
            status: { $nin: ["Used", "Cancelled"] },
        }),
    ]);

    return { ...counts, passSent, checkedIn, notCheckedIn };
};

// Dashboard Summary
// `requestedEventId` (optional): lets the dashboard's own Event selector
// show any ONE non-deleted event on demand — active or inactive/expired —
// instead of only ever auto-picking the currently running one. When
// omitted, behavior is unchanged: getActiveEvent()'s existing
// running-event-else-last-expired-event resolution is used. Either way,
// every number returned (the event details AND the 4 stat cards) is
// scoped to that SAME single event — never combined across multiple
// events.
 const getDashboardSummary = async (requestedEventId) => {

    const activeEvent = requestedEventId
        ? await Event.findOne({
            _id: requestedEventId,
            isDeleted: { $ne: true },
        }).lean()
        : await getActiveEvent();

    if (!activeEvent) {
        return {
            activeEvent: null,
            todayBooking: 0,
            todayPassBooking: 0,
            todayPassAmount: 0,
            todayPassBookingCounts: [],
            totalBooking: 0,
            totalPassBooking: 0,
            totalPassAmount: 0,
            passBookingCounts: [],
            bookingCounts: [],
            totalBookingDetails: [],
            quantityWiseBookings: [],
            totalBookings: 0,
            registeredTickets: 0,
            pendingRegistrations: 0,
            scannedEntries: 0,
            registeredNotScanned: 0,
            crew: await getCrewCounts(null),
        };
    }

    // Scoped to this single resolved/selected event only — see
    // getDashboardCounts above.
    const dashboardCounts = await getDashboardCounts(activeEvent._id);
    // Attendance reminder answers (Yes / No / No response) for this event.
    const rsvp = await getRsvpSummary(activeEvent._id);
    const crew = await getCrewCounts(activeEvent._id);

    const todayBooking = await getTodayBooking(activeEvent._id);
    const todayPassResult = await getTodayPassBooking(activeEvent._id);
    const totalBooking = await getTotalBooking(activeEvent._id);
    const totalPassResult = await getTotalPassBooking(activeEvent._id);
    const bookingCounts = await getBookingCounts(activeEvent._id);
    const totalBookingDetails = await getTotalBookingDetails(
        activeEvent._id
    );
    const quantityWiseBookings = await getQuantityWiseBookings(activeEvent._id);

    return {
        activeEvent,
        todayBooking,
        // Today's booked quantity + amount, ticket-type-wise breakdown.
        todayPassBooking: todayPassResult.totalQty,
        todayPassAmount: todayPassResult.totalAmount,
        todayPassBookingCounts: todayPassResult.passBookingCounts,
        totalBooking,
        // Total quantity of all booked passes across every ticket type
        // (sum of passBookingCounts[].qty), not a document count.
        totalPassBooking: totalPassResult.totalQty,
        // Sum of every ticket type's (qty x TicketType.amount).
        totalPassAmount: totalPassResult.totalAmount,
        // Ticket-Type-wise breakdown: [{ ticketTypeId, ticketName, qty, amount }]
        passBookingCounts: totalPassResult.passBookingCounts,
        bookingCounts,
        totalBookingDetails,
        // Quantity-wise: [{ quantity, bookings, tickets }] - dynamic, no fixed list.
        quantityWiseBookings,
        rsvp,
        crew,
        ...dashboardCounts,
    };
};
module.exports = {
    getDashboardSummary,
};