const express = require("express");
const router = express.Router();

const bookingController = require("../controllers/booking.controller");

const {
  createBookingValidation,
  updateBookingValidation,
  validate,
} = require("../validators/booking.validator");

const { protect } = require("../middlewares/auth.middleware");
const { csvUpload } = require("../middlewares/upload.middleware");

// Create Booking
router.post(
  "/create",
  protect,
  createBookingValidation,
  validate,
  bookingController.createBooking
);

// Edit Booking (all editable fields; see bookingService.updateBooking)
router.put(
  "/update/:id",
  protect,
  updateBookingValidation,
  validate,
  bookingController.updateBooking
);

// Bulk Import Bookings via CSV
// Each row of the CSV is created as its own booking (line by line), and
// each successful booking automatically gets its registration link sent
// via WhatsApp — same as a normal single booking created through
// POST /create, since this reuses bookingService.createBooking internally.
router.post(
  "/import-csv",
  protect,
  csvUpload.single("file"),
  bookingController.importBookingsCsv
);

// Check a CSV before importing it (creates nothing) — warns about rows
// that share a mobile number.
router.post(
  "/import-csv/check",
  protect,
  csvUpload.single("file"),
  bookingController.checkBookingsCsv
);

// Get All Bookings
router.get(
  "/get-all-bookings",
  protect,
  bookingController.getAllBookings
);

// Export Bookings
router.get(
  "/export",
  protect,
  bookingController.exportBookingsController
);

// Delete Booking
router.delete(
  "/delete/:id",
  protect,
  bookingController.deleteBooking
);

// Get Booking By ID
router.get(
  "/:id",
  protect,
  bookingController.getBookingById
);

module.exports = router;