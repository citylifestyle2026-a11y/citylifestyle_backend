const { body, validationResult } = require("express-validator");
const { parseInstagramLink } = require("../utils/normalizeInstagramId");
const {
  mobileCustomValidator,
  toLocalMobileNumber,
  toLocalMobileSanitizer,
} = require("../utils/normalizeMobileNumber");

// ================= MULTIPART BODY PARSER =================
// The Create/Edit Contact form now submits multipart/form-data (profile
// photo + spouse photo are files), and a multipart body can only carry
// strings — so the frontend sends `references` as a JSON string. This
// turns it back into a real array BEFORE the validators below run.
// Plain JSON requests (references already an array) pass straight
// through, so existing API clients keep working.
const parseContactFormData = (req, res, next) => {
  if (req.body && typeof req.body.references === "string") {
    try {
      const parsed = JSON.parse(req.body.references);
      req.body.references = Array.isArray(parsed) ? parsed : [];
    } catch (error) {
      req.body.references = [];
    }
  }
  next();
};

// Area / Instagram ID rules shared by create AND update. Both are
// COMPULSORY; the Spouse Instagram ID is compulsory only for Couple
// (ignored for Single). Instagram IDs are normalized first ("@name",
// "name" and a pasted instagram.com link all become "name"), then checked.
// The Profile Photo / Spouse Profile Photo are files, so their
// "required" rule is enforced in services/contact.service.js.
// Instagram is OPTIONAL and must be a profile LINK (a plain name is rejected).
// It is stored as the bare username parsed out of that link.
const instagramRule = (field, label, { coupleOnly = false } = {}) =>
  body(field)
    .custom((value, { req }) => {
      if (coupleOnly && req.body.relationship !== "Couple") return true;

      const raw = String(value ?? "").trim();
      if (!raw) return true; // optional

      if (!parseInstagramLink(raw)) {
        throw new Error(
          `${label}: please enter the Instagram profile link (e.g. https://instagram.com/username), not a name`
        );
      }
      return true;
    })
    .customSanitizer((value) => parseInstagramLink(value) || "");

const contactExtraFieldValidation = [
  body("area").trim().notEmpty().withMessage("Area is required"),
  instagramRule("instagramId", "Instagram Link"),
  instagramRule("spouseInstagramId", "Spouse Instagram Link", {
    coupleOnly: true,
  }),
];

// Edit: nothing is compulsory. Only the FORMAT of values that are actually
// filled in is checked (Instagram link, mobile numbers, email, ids).
const contactUpdateExtraFieldValidation = [
  body("area").optional({ values: "falsy" }).trim(),
  instagramRule("instagramId", "Instagram Link"),
  instagramRule("spouseInstagramId", "Spouse Instagram Link", {
    coupleOnly: true,
  }),
];

// Create Contact Validation
// This only checks shape/type/presence — trimming and case-insensitive
// de-duplication of `references` happens in the model itself
// (models/contact.model.js's pre-save/pre-findOneAndUpdate hooks), same
// separation of concerns already used elsewhere in this project (e.g.
// User.model.js hashes `password` in a hook rather than the validator).
// Every field is compulsory EXCEPT `address` — see the matching
// `updateContactValidation` below, which mirrors this field-for-field.
const createContactValidation = [
  body("fullName")
    .trim()
    .notEmpty()
    .withMessage("Full Name is required"),

  // Accepts 9876543210 / 919876543210 / +91 98765 43210 — saved as the
  // 10-digit number (see utils/normalizeMobileNumber.js).
  body("whatsappNumber")
    .trim()
    .notEmpty()
    .withMessage("WhatsApp Number is required")
    .bail()
    .custom(
      mobileCustomValidator(
        "Invalid WhatsApp Number (10 digits, with or without 91)"
      )
    )
    .customSanitizer(toLocalMobileSanitizer),

  // Company Name, Designation and Company Category are optional.
  body("companyName").optional({ values: "falsy" }).trim(),

  body("designation").optional({ values: "falsy" }).trim(),

  // Address is the one field that's allowed to be blank.
  body("address")
    .optional({ values: "falsy" })
    .trim(),

  // At least one reference is required — duplicate removal
  // (case-insensitive, within this same contact) is the model's job,
  // not this validator's.
  body("references")
    .isArray({ min: 1 })
    .withMessage("At least one Reference is required"),

  body("references.*")
    .isString()
    .withMessage("Each reference must be text")
    .trim()
    .notEmpty()
    .withMessage("Reference cannot be empty"),

  body("companyCategory")
    .optional({ values: "falsy" })
    .isMongoId()
    .withMessage("Invalid Company Category"),

  // Email follows the same optional-but-validated-if-present style
  // already used by validators/guest.validator.js's own `email` field
  // (checkFalsy so an empty string is treated as "not provided", not a
  // format error).
  body("email")
    .optional({ checkFalsy: true })
    .trim()
    .isEmail()
    .withMessage("Invalid email address"),

  // Single / Couple — required outright, independent of every
  // conditional rule below. No gender is inferred from this value
  // anywhere in this validator or the service.
  // The form now sends `entryType` (Single / Couple); `relationship` is only sent
  // by clients that still use the spouse section. One of the two is required.
  body("relationship")
    .optional({ values: "falsy" })
    .trim()
    .isIn(["Single", "Couple"])
    .withMessage('Relationship must be "Single" or "Couple"'),

  body("entryType")
    .trim()
    .custom((value, { req }) => {
      const v = String(value || "").trim();
      if (!v && !String(req.body.relationship || "").trim()) {
        throw new Error("Entry Type is required");
      }
      if (v && !["Single", "Couple", "Manual"].includes(v)) {
        throw new Error('Entry Type must be "Single", "Couple" or "Manual"');
      }
      return true;
    }),

  // Manual entry: the admin types how many persons (1 - 1000).
  body("persons")
    .optional({ values: "falsy" })
    .custom((value, { req }) => {
      if (String(req.body.entryType || "").trim() !== "Manual") return true;
      const n = Number(value);
      if (!Number.isInteger(n) || n < 1 || n > 1000) {
        throw new Error("Persons must be a whole number between 1 and 1000");
      }
      return true;
    }),
  body("entryType").custom((value, { req }) => {
    if (String(value || "").trim() === "Manual" && !String(req.body.persons || "").trim()) {
      throw new Error("Persons is required for a Manual entry");
    }
    return true;
  }),

  // ================= CONDITIONAL: COUPLE-ONLY REQUIRED FIELDS =================
  // spouseName / spouseMobile / profession are each only required when
  // this same submission's `relationship` is "Couple" — when it's
  // "Single" they're accepted blank. Read directly off `req.body`
  // (already validated/normalized above by the time these run, since
  // express-validator runs body() checks in the order they're declared)
  // rather than duplicating the enum check.
  body("spouseName")
    .trim()
    .custom((value, { req }) => {
      if (req.body.relationship === "Couple" && !String(value || "").trim()) {
        throw new Error("Spouse Name is required for Couple");
      }
      return true;
    }),

  // Same "required only for Couple" rule as spouseName above, plus the
  // exact same 10-digit-with-or-without-91 format/normalization already
  // used by `whatsappNumber` (utils/normalizeMobileNumber.js) — applied
  // only when a value is actually present, so a blank Single submission
  // is never rejected for "invalid format".
  body("spouseMobile")
    .trim()
    .custom((value, { req }) => {
      const trimmed = String(value || "").trim();
      const isCouple = req.body.relationship === "Couple";

      if (isCouple && !trimmed) {
        throw new Error("Spouse Mobile Number is required for Couple");
      }

      if (trimmed && !toLocalMobileNumber(trimmed)) {
        throw new Error(
          "Invalid Spouse Mobile Number (10 digits, with or without 91)"
        );
      }

      return true;
    })
    .customSanitizer(toLocalMobileSanitizer),

  // Profession/Occupation — required only for Couple per this step's
  // spec, same conditional pattern as spouseName/spouseMobile above.
  // Profession text is no longer asked for: the spouse only picks a Category
  // (professionCategory below). The frontend still fills `profession` with the
  // category name so lists/exports keep showing it.
  body("profession").optional({ values: "falsy" }).trim(),

  // Spouse's profession Category (from the Company Category list) —
  // compulsory for Couple, ignored for Single.
  body("professionCategory").custom((value, { req }) => {
    const v = String(value ?? "").trim();
    if (req.body.relationship === "Couple" && !v) {
      throw new Error("Category is required for Couple");
    }
    if (v && !/^[0-9a-fA-F]{24}$/.test(v)) {
      throw new Error("Invalid Category");
    }
    return true;
  }),

  ...contactExtraFieldValidation,
];

// Update Contact Validation
// Mirrors createContactValidation field-for-field — the Edit form
// (CreateContactModal.jsx in edit mode) always resubmits the full set
// of fields, so the same "every field except Address is compulsory"
// rule applies here too. `fullName`/`whatsappNumber` keep `.optional()`
// (checked only when present) purely so a value that's already valid
// on the existing document is never re-rejected just for being
// "missing" from a differently-shaped request; every other field below
// is required outright, same as create.
const updateContactValidation = [
  body("fullName").optional({ values: "falsy" }).trim(),

  body("whatsappNumber")
    .optional({ values: "falsy" })
    .trim()
    .custom(
      mobileCustomValidator(
        "Invalid WhatsApp Number (10 digits, with or without 91)"
      )
    )
    .customSanitizer(toLocalMobileSanitizer),

  body("companyName").optional({ values: "falsy" }).trim(),

  body("designation").optional({ values: "falsy" }).trim(),

  body("address").optional({ values: "falsy" }).trim(),

  // References may be left empty on edit; if sent, each must be text.
  body("references").optional().isArray().withMessage("References must be a list"),

  body("references.*")
    .optional()
    .isString()
    .withMessage("Each reference must be text")
    .trim(),

  body("companyCategory")
    .optional({ values: "falsy" })
    .isMongoId()
    .withMessage("Invalid Company Category"),

  body("email")
    .optional({ checkFalsy: true })
    .trim()
    .isEmail()
    .withMessage("Invalid email address"),

  body("relationship")
    .optional({ values: "falsy" })
    .trim()
    .isIn(["Single", "Couple"])
    .withMessage('Relationship must be "Single" or "Couple"'),

  body("entryType")
    .optional({ values: "falsy" })
    .trim()
    .isIn(["Single", "Couple", "Manual"])
    .withMessage('Entry Type must be "Single", "Couple" or "Manual"'),

  body("persons")
    .optional({ values: "falsy" })
    .custom((value) => {
      const n = Number(value);
      if (!Number.isInteger(n) || n < 1 || n > 1000) {
        throw new Error("Persons must be a whole number between 1 and 1000");
      }
      return true;
    }),

  body("spouseName").optional({ values: "falsy" }).trim(),

  body("spouseMobile")
    .optional({ values: "falsy" })
    .trim()
    .custom((value) => {
      const trimmed = String(value || "").trim();
      if (trimmed && !toLocalMobileNumber(trimmed)) {
        throw new Error(
          "Invalid Spouse Mobile Number (10 digits, with or without 91)"
        );
      }
      return true;
    })
    .customSanitizer(toLocalMobileSanitizer),

  body("profession").optional({ values: "falsy" }).trim(),

  body("professionCategory").optional({ values: "falsy" }).custom((value) => {
    const v = String(value ?? "").trim();
    if (v && !/^[0-9a-fA-F]{24}$/.test(v)) {
      throw new Error("Invalid Category");
    }
    return true;
  }),

  ...contactUpdateExtraFieldValidation,
];

// Validation Result
// Same shape already used by event.validator.js / ticketType.validator.js /
// user.validator.js / admin.validator.js — surfaces the first field
// error as `message` (what the frontend's error handling reads) while
// still returning the full `errors` array.
const validate = (req, res, next) => {
  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    const errorList = errors.array();

    return res.status(400).json({
      success: false,
      message: errorList[0].msg,
      errors: errorList,
    });
  }

  next();
};

module.exports = {
  parseContactFormData,
  createContactValidation,
  updateContactValidation,
  validate,
};